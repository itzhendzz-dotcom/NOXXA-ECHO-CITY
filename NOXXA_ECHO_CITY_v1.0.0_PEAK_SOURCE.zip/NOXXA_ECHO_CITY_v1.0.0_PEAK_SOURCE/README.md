# NOXXA ECHO//CITY v1.0.0

**Procedural micro-horror director for GTA: San Andreas Android + AML + SAUtils.**

ECHO//CITY does not replace missions and does not touch the visual pipeline. It quietly watches normal free-roam and, under safe conditions, injects one short impossible event built around the player's camera and memory of movement.

> The city should feel wrong before it feels haunted.

## The three encounters

### 01 — WATCHER

A harmless pedestrian appears at a validated hidden node behind the active camera.

- When actually visible, it **cannot relocate**.
- Staring at it charges the next unseen movement.
- Look away and, after a grace period, it may advance through another validated pedestrian node.
- Every destination is screened before teleport: node plausibility, visibility, obstruction and Z sanity.
- Near the player it enters a finale. Catch it again and it holds for a beat, then disappears. No attack, no cheap damage.

The intended feeling is not “NPC chasing me”. It is: **“I swear that thing was farther away.”**

### 02 — ECHO

The director maintains a fixed ~25-second ring of the player's recent outdoor movement. ECHO selects an older slice and creates a figure near that past route.

- While unseen, it replays old player positions.
- It refuses stale history, large teleports, impossible node snaps and visible destinations.
- If observed long enough, route replay stops. The figure turns toward the player.
- Look away after it becomes aware and it vanishes.
- When safe, ECHO can borrow the player's already-loaded normal ped model; otherwise it uses a fallback model without stealing model ownership.

It is essentially a delayed ghost of where you were, not an AI follower.

### 03 — SIGNAL

The cheapest event: no ped at all, only two tiny red coronas.

SIGNAL appears far away. See it, stare briefly, then look away. The next time it exists, it is closer. Four distance stages collapse from roughly 50 m to around 10 m before the final see/look-away cycle removes it.

SIGNAL is also the director's low-FPS fallback because it owns no model or ped.

---

## Why this version is different from a typical CLEO horror script

ECHO//CITY is built as a **native AML state machine with a strict ownership budget**:

- maximum **1 owned ped** at any time;
- maximum **2 tiny coronas**;
- fixed-size history/state buffers, no event-loop heap churn;
- camera-relative spawn search using active camera position and point-at;
- screen-space visibility plus optional world line-of-sight;
- pedestrian-node snapping with horizontal and vertical tolerances;
- automatic mission guard resolved by symbol name, not guessed GTA addresses;
- wanted / vehicle / interior / multiplayer cleanup gates;
- FPS admission control plus a sustained-low-FPS emergency cleanup;
- event selection that degrades toward SIGNAL when the FPS budget gets tight;
- no shader pass, textures, animation pack or audio stream required.

Most importantly, an ambiguous state resolves to **refuse the event** instead of forcing something “cool” and risking an FC.

## Performance / visual non-interference contract

ECHO//CITY intentionally does **not** modify:

- timecycle / colorcycle;
- fog, rain, wet road, lightning or godrays;
- SSAO, bloom, FXAA or post processing;
- frame limiter / refresh rate;
- resolution scale;
- draw distance;
- traffic or pedestrian density;
- FLA limits;
- JPatch settings;
- HUD/radar state.

The preflight script contains a denylist for several global-mutating opcodes so accidental scope creep fails CI.

## Automatic director

Three intensity profiles alter cooldown, weights and Watcher aggression:

| Intensity | Auto cooldown | Bias |
|---|---:|---|
| **Subtle** | ~180–360 s | rarer, more SIGNAL |
| **Balanced** | ~100–220 s | default mixture |
| **Nightmare** | ~55–125 s | more ped events, faster Watcher |

Immediate event repetition is down-weighted. ECHO has no effective selection weight until enough valid movement history exists.

Default auto window is **21:00–05:00**. Manual force buttons ignore night/FPS/mission admission for diagnostics, but still respect core unsafe-state gates such as vehicle, wanted level and interiors.

## Default tuning

| Setting | Default |
|---|---:|
| Director | ON |
| Intensity | Balanced |
| Night only | ON |
| Night window | 21:00–05:00 |
| Red eyes | ON |
| Clone player model for ECHO | ON when safe |
| World LOS check | ON |
| Strict mission guard | ON |
| Multiplayer | OFF / refused |
| Minimum FPS admission | 42 |
| Logic tick | 75 ms |
| Visibility tick | 40 ms |
| History tick | 350 ms |
| Watcher lifetime | 44 s |
| ECHO lifetime | 30 s |
| SIGNAL lifetime | 28 s |
| Watcher base spawn distance | 32 m |
| Watcher base step | 2.55 m |
| Watcher base step interval | 650 ms |
| Watcher stop distance | 6.2 m |
| Stare charge | 1500 ms |

Advanced values are config-only by design. The in-game tab exposes the settings worth changing often without turning Settings into a debug console.

## In-game menu

`Settings → ECHO//CITY`

- **Director** — automatic event system on/off.
- **Intensity** — Subtle / Balanced / Nightmare.
- **Red Eyes** — corona eye rendering.
- **Clone Player Echo** — allow safe normal-player ped model borrowing.
- **Minimum FPS** — admission threshold.
- **FORCE RANDOM** — force a director choice now.
- **FORCE WATCHER** — controlled Watcher test.
- **FORCE ECHO** — requires enough recent movement history.
- **FORCE SIGNAL** — cheapest smoke test.
- **DESPAWN EVENT** — deterministic cleanup.

## Safety gates

An automatic encounter is refused or an active one is cleaned when appropriate if:

- player handle becomes invalid/dead;
- player enters a vehicle;
- wanted level rises above zero;
- GTA reports a non-zero interior world;
- a story mission becomes active;
- common multiplayer runtimes are detected and `AllowMultiplayer=0`;
- spawn/path candidates are invalid;
- ped-event FPS stays severely below budget.

Mission state uses `CTheScripts::IsPlayerOnAMission()` resolved by symbol. If the symbol is unavailable and strict mission guard is enabled, automatic events fail closed rather than guessing a version-specific offset.

## Host validation already built into the repo

Run:

```bash
./scripts/preflight.sh
```

It executes eleven gates:

1. pure C++ core tests;
2. ASan + UBSan core tests;
3. whole `main.cpp` GCC API-shape compile with warnings-as-errors;
4. independent Clang API-shape compile;
5. shell script syntax checks;
6. workflow YAML parse/sanity;
7. forbidden global-state mutation scan;
8. Android build-recipe/dependency-pin audit;
9. stale prototype marker scan;
10. packaging dry-run with ZIP/manifest verification;
11. release metadata/document presence.

The core tests cover geometry, camera-behind math, night-window wraparound, FPS EMA, breadcrumb ring wrap/age queries, weighted director choices and timer saturation.

## Reproducible Android build

Dependencies are **pinned**, not fetched from moving `main` branches during a release build:

- AndroidModLoader source snapshot: `5588ed242b8e49fc1def572aef89c6c9e745aa34`
- SAUtils header snapshot: `ace8752de2d0fa502b027bd0a9c6ca2d3bcd04e8`
- Android NDK: `27.3.13750724` (r27d)

GitHub Actions builds both:

```text
armeabi-v7a/libECHO_CITY.so
arm64-v8a/libECHO_CITY.so
```

Then it checks ELF headers, generates SHA-256 hashes, creates a manifest, tests ZIP integrity and uploads the ready package.

### GitHub build

1. Create/upload this project as a repository, preserving `.github/workflows/build.yml`.
2. Open **Actions → Build ECHO CITY → Run workflow**.
3. Download the final `NOXXA-ECHO-CITY-<commit>` artifact after all jobs pass.
4. Install the `.so` matching the ABI used by your GTA/AML build.

See [`INSTALL.md`](INSTALL.md) for the smoke-test sequence.

### Local NDK build

```bash
./scripts/fetch_deps.sh
export ANDROID_NDK_HOME=/path/to/android-ndk-r27d
./scripts/build.sh
./scripts/package.sh
```

## Project map

```text
main.cpp                       AML integration + all runtime state machines
src/echo_core.h                vectors, camera geometry, history ring, FPS EMA
src/director_logic.h           event weights / intensity / timer helpers
tests/test_core.cpp            deterministic host unit tests
tests/stubs/                   API-shape stubs for whole-main compile gate
scripts/preflight.sh           six host/safety gates
scripts/fetch_deps.sh          reproducible AML + SAUtils dependency pins
scripts/build.sh               dual-ABI NDK build helper
scripts/package.sh             hashes + manifest + ready ZIP
.github/workflows/build.yml    preflight → ABI matrix → final artifact
docs/ARCHITECTURE.md           director/state-machine design
docs/OPCODE_AUDIT.md          every script command ownership boundary
docs/TEST_PLAN.md              device regression/soak checklist
docs/COMPATIBILITY.md          known interactions and failure philosophy
CHANGELOG.md                   v1.0 rebuild notes
INSTALL.md                     build/install/smoke-test instructions
```

## Status

This source package is designed to be buildable and testable, but the final truth for any native GTA Android mod is an **on-device test against the exact GTA/AML/SAUtils/mod-stack combination**. Host preflight catches logic/API/source regressions; it cannot emulate RenderWare streaming, Android entity pools, or a specific patched APK.

That distinction is intentional: the project never claims a native `.so` is “device proven” until it has actually been run on the target game.
