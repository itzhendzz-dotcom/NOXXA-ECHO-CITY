LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_CPP_EXTENSION := .cpp .cc
LOCAL_MODULE := ECHO_CITY
# logger.cpp + config.cpp are part of every normal AML native mod using
# MYMODCFG/logger; omitting them can pass host syntax checks but fail at link.
LOCAL_SRC_FILES := main.cpp mod/logger.cpp mod/config.cpp
LOCAL_C_INCLUDES += $(LOCAL_PATH)
LOCAL_CPPFLAGS += -std=c++17 -O2 -DNDEBUG -fvisibility=hidden -ffunction-sections -fdata-sections -Wall -Wextra
LOCAL_LDFLAGS += -Wl,--gc-sections
LOCAL_LDLIBS += -llog -ldl
include $(BUILD_SHARED_LIBRARY)
