#pragma once
#include <cstddef>
#include <cstdint>
#define IAML_VER 01040100
struct IAML {
    void* GetLibHandle(const char*) { return reinterpret_cast<void*>(1); }
    uintptr_t GetSym(void*, const char*) { return 1; }
    bool HasMod(const char*) { return false; }
};
extern IAML* aml;
#define MYMODCFG(guid,name,version,author) IAML* aml = nullptr; Config* cfg = nullptr;
#define NEEDGAME(pkg)
#define BEGIN_DEPLIST()
#define ADD_DEPENDENCY_VER(guid,ver)
#define END_DEPLIST()
#define ON_MOD_LOAD() extern "C" void OnModLoad()
#define ON_MOD_UNLOAD() extern "C" void OnModUnload()
inline void* GetInterface(const char*) { return nullptr; }
