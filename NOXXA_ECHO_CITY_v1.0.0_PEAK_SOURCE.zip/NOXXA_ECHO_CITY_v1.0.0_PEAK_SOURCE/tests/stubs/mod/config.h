#pragma once
#include <cstddef>
class Config;
class ConfigEntry {
public:
    bool GetBool() const { return false; }
    int GetInt() const { return 0; }
    float GetFloat() const { return 0.0f; }
    int Clamp(int,int) { return 0; }
    float Clamp(float,float) { return 0.0f; }
    void SetBool(bool) {}
    void SetInt(int) {}
};
class Config {
public:
    ConfigEntry* Bind(const char*, bool, const char* = "Preferences") { return new ConfigEntry; }
    ConfigEntry* Bind(const char*, int, const char* = "Preferences") { return new ConfigEntry; }
    ConfigEntry* Bind(const char*, float, const char* = "Preferences") { return new ConfigEntry; }
    void Save() {}
};
extern Config* cfg;
