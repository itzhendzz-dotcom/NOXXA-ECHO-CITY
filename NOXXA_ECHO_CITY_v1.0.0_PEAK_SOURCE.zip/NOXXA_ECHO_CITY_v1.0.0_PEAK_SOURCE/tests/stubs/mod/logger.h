#pragma once
#include <cstdarg>
enum eLogPrio { LogP_Unk=0, LogP_Default, LogP_Verbose, LogP_Debug, LogP_Info, LogP_Warn, LogP_Error };
struct Logger {
    void SetTag(const char*) {}
    void Info(const char*, ...) {}
    void Error(const char*, ...) {}
    void Print(eLogPrio, const char*, ...) {}
};
extern Logger* logger;
