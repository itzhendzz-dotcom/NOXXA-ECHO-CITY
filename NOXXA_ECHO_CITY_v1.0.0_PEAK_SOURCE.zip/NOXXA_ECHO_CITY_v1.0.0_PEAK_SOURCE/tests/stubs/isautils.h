#pragma once
#include <cstdint>
#define MAX_SCRIPT_VARS 16
#define _VA_ARGS(...) , ##__VA_ARGS__
struct SCRIPT_COMMAND { uint16_t opCode; char params[MAX_SCRIPT_VARS]; };
#define DEFOPCODE(op,name,args) const SCRIPT_COMMAND scm_##name = {0x##op, #args}
#define CALLSCM(name, ...) sautils->ScriptCommand(&scm_##name _VA_ARGS(__VA_ARGS__))
typedef void (*OnSettingChangedFn)(int,int,void*);
typedef const char* (*OnSettingDrawedFn)(int,void*);
typedef void (*OnButtonPressedFn)(uintptr_t);
typedef void (*OnPlayerProcessFn)(uintptr_t);
enum eTypeOfSettings : unsigned char { SetType_Controller=0, SetType_Game, SetType_Display, SetType_Audio, SetType_Language, SetType_Mods, SETTINGS_COUNT };
struct ISAUtils {
    int ScriptCommand(const SCRIPT_COMMAND*, ...) { return 0; }
    unsigned int GetCurrentMs() { return 0; }
    float GetCurrentFPS() { return 120.0f; }
    eTypeOfSettings AddSettingsTab(const char*, const char* = "menu_mainsettings") { return SetType_Mods; }
    int AddClickableItem(eTypeOfSettings,const char*,int=0,int=0,int=0,const char** = nullptr,OnSettingChangedFn=nullptr) { return 0; }
    int AddSliderItem(eTypeOfSettings,const char*,int=0,int=0,int=0,OnSettingChangedFn=nullptr,OnSettingDrawedFn=nullptr) { return 0; }
    void AddButton(eTypeOfSettings,const char*,OnButtonPressedFn=nullptr) {}
    void AddPlayerUpdateListener(OnPlayerProcessFn,bool=true) {}
};
