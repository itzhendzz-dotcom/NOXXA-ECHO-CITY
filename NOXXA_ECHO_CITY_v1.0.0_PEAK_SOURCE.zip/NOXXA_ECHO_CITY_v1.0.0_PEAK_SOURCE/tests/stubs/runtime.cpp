#include <mod/logger.h>
#include <mod/config.h>
Logger gLogger; Logger* logger = &gLogger;
Config gCfg; Config* cfg = &gCfg;
