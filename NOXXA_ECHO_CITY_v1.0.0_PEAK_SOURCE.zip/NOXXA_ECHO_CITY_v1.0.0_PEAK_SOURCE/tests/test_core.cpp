#include "../src/echo_core.h"
#include "../src/director_logic.h"

#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>

static bool nearf(float a, float b, float eps = 0.001f) { return std::fabs(a - b) <= eps; }

int main() {
    using namespace echo;

    // Night window: wrap-around + same-hour 24h mode.
    assert(isWithinNightWindow(23, 21, 5));
    assert(isWithinNightWindow(2, 21, 5));
    assert(!isWithinNightWindow(12, 21, 5));
    assert(isWithinNightWindow(12, 0, 0));

    // Heading basis used by GTA-facing geometry.
    Vec3 p{0, 0, 10};
    Vec3 b = pointBehind(p, 0.0f, 30.0f, 0.0f);
    assert(nearf(b.x, 0.0f));
    assert(nearf(b.y, -30.0f));

    Vec3 view{0.0f, 1.0f, 0.0f};
    Vec3 bv = pointBehindView(p, view, 30.0f, 0.0f, 0.0f);
    assert(nearf(bv.x, 0.0f));
    assert(nearf(bv.y, -30.0f));

    Vec3 side = pointBehindView(p, view, 10.0f, 0.0f, 3.0f);
    assert(nearf(side.x, 3.0f));
    assert(nearf(side.y, -10.0f));

    Vec3 s = approach({0, 0, 0}, {10, 0, 0}, 2.5f);
    assert(nearf(s.x, 2.5f));
    assert(nearf(distance2D({0,0,0}, {3,4,10}), 5.0f));
    assert(nodeLooksPlausible({0,0,10}, {3,4,12}, 6.0f, 3.0f));
    assert(!nodeLooksPlausible({0,0,10}, {20,0,10}, 6.0f, 3.0f));
    assert(stepLooksPlausible({0,0,0}, {3,0,1}, 2.5f, 1.0f, 2.0f));
    assert(!stepLooksPlausible({0,0,0}, {7,0,0}, 2.5f, 1.0f, 2.0f));

    assert(nearf(headingTo({0,0,0}, {0,1,0}), 0.0f));
    assert(nearf(headingTo({0,0,0}, {1,0,0}), 90.0f));

    Vec3 l{}, r{};
    eyePair({0,0,0}, 0.0f, 1.6f, 0.1f, l, r);
    assert(nearf(l.x, -0.1f));
    assert(nearf(r.x, 0.1f));
    assert(nearf(l.z, 1.6f) && nearf(r.z, 1.6f));

    // EMA rejects nonsense samples and converges without a big first-sample bias.
    FpsEma fps(0.25f);
    assert(nearf(fps.push(120.0f), 120.0f));
    assert(nearf(fps.push(80.0f), 110.0f));
    assert(nearf(fps.push(0.0f), 110.0f));

    // Breadcrumb ring ordering survives wrap-around.
    BreadcrumbRing<4> ring;
    for (std::uint32_t i = 0; i < 6; ++i) {
        ring.push({{static_cast<float>(i), 0, 0}, 0.0f, i * 1000u, 0});
    }
    assert(ring.size() == 4);
    assert(nearf(ring.atChronological(0).pos.x, 2.0f));
    assert(nearf(ring.atChronological(3).pos.x, 5.0f));
    const Breadcrumb* old = ring.findClosestAge(6000u, 3000u, 100u, 0);
    assert(old && nearf(old->pos.x, 3.0f));

    Breadcrumb copied[4]{};
    std::size_t n = ring.copyFromTime(3000u, 0, copied, 4);
    assert(n == 3);
    assert(nearf(copied[0].pos.x, 3.0f));
    assert(nearf(copied[2].pos.x, 5.0f));

    // History age/copy queries also survive the GTA 32-bit timer wrapping.
    BreadcrumbRing<4> wrapRing;
    wrapRing.push({{1,0,0}, 0.0f, 0xFFFFFF00u, 0});
    wrapRing.push({{2,0,0}, 0.0f, 0xFFFFFF80u, 0});
    wrapRing.push({{3,0,0}, 0.0f, 100u, 0});
    const Breadcrumb* wrappedOld = wrapRing.findClosestAge(500u, 756u, 20u, 0);
    assert(wrappedOld && nearf(wrappedOld->pos.x, 1.0f));
    Breadcrumb wrapCopied[4]{};
    const std::size_t wn = wrapRing.copyFromTime(0xFFFFFF80u, 0, wrapCopied, 4);
    assert(wn == 2);
    assert(nearf(wrapCopied[0].pos.x, 2.0f));
    assert(nearf(wrapCopied[1].pos.x, 3.0f));

    // Intensity profiles and anti-repeat director behavior.
    auto subtle = profileFor(Intensity::Subtle);
    auto nightmare = profileFor(Intensity::Nightmare);
    assert(subtle.cooldownMinSec > nightmare.cooldownMinSec);
    assert(nightmare.watcherStepScale > subtle.watcherStepScale);

    // No history => Echo must never be selected.
    for (int roll = 0; roll < 100; ++roll) {
        assert(chooseWeightedEvent(roll, Intensity::Balanced, EventType::None, false, false) != EventType::Echo);
    }
    // Tight budget biases toward Signal.
    int signalNormal = 0, signalBudget = 0;
    for (int roll = 0; roll < 100; ++roll) {
        if (chooseWeightedEvent(roll, Intensity::Balanced, EventType::None, true, false) == EventType::Signal) ++signalNormal;
        if (chooseWeightedEvent(roll, Intensity::Balanced, EventType::None, true, true) == EventType::Signal) ++signalBudget;
    }
    assert(signalBudget > signalNormal);

    // Deadline comparison remains valid across the 32-bit GTA timer wrap.
    assert(scheduleAfterSeconds(1000u, 2) == 3000u);
    const std::uint32_t wrapped = scheduleAfterMs(0xFFFFFF00u, 1000u);
    assert(wrapped == 744u);
    assert(!timeReached(0xFFFFFF80u, wrapped));
    assert(timeReached(800u, wrapped));

    // Deterministic property sweep: camera-behind math keeps requested radial
    // distance and approach() never overshoots its target.
    std::uint32_t lcg = 0xC0FFEEu;
    for (int i = 0; i < 5000; ++i) {
        lcg = lcg * 1664525u + 1013904223u;
        const float heading = static_cast<float>(lcg % 36000u) / 100.0f;
        lcg = lcg * 1664525u + 1013904223u;
        const float dist = 1.0f + static_cast<float>(lcg % 7000u) / 100.0f;
        const Vec3 origin{12.5f, -7.25f, 4.0f};
        const Vec3 behind = pointBehind(origin, heading, dist, 0.0f);
        assert(std::fabs(distance2D(origin, behind) - dist) < 0.002f);

        const Vec3 target{behind.x + 9.0f, behind.y - 4.0f, behind.z};
        const float before = distance2D(behind, target);
        const Vec3 stepped = approach(behind, target, 2.75f);
        const float after = distance2D(stepped, target);
        assert(after <= before + 0.0001f);
        assert(distance2D(behind, stepped) <= 2.7501f);
    }

    std::cout << "ECHO//CITY v1 core tests: PASS\n";
    return 0;
}
