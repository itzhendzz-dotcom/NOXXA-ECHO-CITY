#pragma once

#include <algorithm>
#include <cstdint>

namespace echo {

enum class EventType : int {
    None = 0,
    Watcher = 1,
    Echo = 2,
    Signal = 3,
};

enum class Intensity : int {
    Subtle = 0,
    Balanced = 1,
    Nightmare = 2,
};

struct IntensityProfile {
    int cooldownMinSec;
    int cooldownMaxSec;
    float watcherStepScale;
    float watcherIntervalScale;
    int watcherWeight;
    int echoWeight;
    int signalWeight;
};

inline IntensityProfile profileFor(Intensity intensity) {
    switch (intensity) {
        case Intensity::Subtle:
            return {180, 360, 0.86f, 1.18f, 30, 25, 45};
        case Intensity::Nightmare:
            return {55, 125, 1.28f, 0.78f, 50, 35, 15};
        case Intensity::Balanced:
        default:
            return {100, 220, 1.00f, 1.00f, 45, 30, 25};
    }
}

inline int clampIntensity(int raw) { return std::max(0, std::min(2, raw)); }

inline EventType chooseWeightedEvent(int roll0To99, Intensity intensity,
                                     EventType lastEvent, bool echoReady,
                                     bool preferSignalForBudget) {
    IntensityProfile p = profileFor(intensity);
    int wWatcher = p.watcherWeight;
    int wEcho = echoReady ? p.echoWeight : 0;
    int wSignal = p.signalWeight;

    if (preferSignalForBudget) {
        wWatcher /= 3;
        wEcho /= 3;
        wSignal += 45;
    }

    // Anti-repeat: keep the director surprising instead of rolling the same event forever.
    if (lastEvent == EventType::Watcher) wWatcher = std::max(1, wWatcher / 2);
    if (lastEvent == EventType::Echo) wEcho = std::max(1, wEcho / 2);
    if (lastEvent == EventType::Signal) wSignal = std::max(1, wSignal / 2);

    const int total = wWatcher + wEcho + wSignal;
    if (total <= 0) return EventType::Signal;

    const int roll = std::max(0, std::min(99, roll0To99));
    const int scaled = (roll * total) / 100;
    if (scaled < wWatcher) return EventType::Watcher;
    if (scaled < wWatcher + wEcho) return EventType::Echo;
    return EventType::Signal;
}

// GTA's millisecond timer is a 32-bit counter. Compare deadlines with signed
// modular arithmetic so a session crossing the ~49.7-day wrap does not wedge
// the director. All ECHO//CITY deadlines are far below the 2^31-ms horizon.
inline bool timeReached(std::uint32_t now, std::uint32_t deadline) {
    return static_cast<std::int32_t>(now - deadline) >= 0;
}

inline std::uint32_t scheduleAfterMs(std::uint32_t now, std::uint32_t delayMs) {
    std::uint32_t target = now + delayMs; // intentional modulo-2^32 wrap
    return target == 0u ? 1u : target;    // 0 is reserved as "not scheduled"
}

inline std::uint32_t scheduleAfterSeconds(std::uint32_t now, int seconds) {
    const std::uint32_t safeSeconds = static_cast<std::uint32_t>(std::max(0, std::min(seconds, 86400)));
    return scheduleAfterMs(now, safeSeconds * 1000u);
}

} // namespace echo
