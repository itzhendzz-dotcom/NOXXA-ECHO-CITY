#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>

namespace echo {

constexpr float kPi = 3.14159265358979323846f;

struct Vec3 {
    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;
};

struct Breadcrumb {
    Vec3 pos{};
    float heading = 0.0f;
    std::uint32_t timeMs = 0;
    int interior = 0;
};

inline float degToRad(float degrees) { return degrees * (kPi / 180.0f); }
inline float radToDeg(float radians) { return radians * (180.0f / kPi); }

inline float distance2D(const Vec3& a, const Vec3& b) {
    const float dx = b.x - a.x;
    const float dy = b.y - a.y;
    return std::sqrt(dx * dx + dy * dy);
}

inline float distance3D(const Vec3& a, const Vec3& b) {
    const float dx = b.x - a.x;
    const float dy = b.y - a.y;
    const float dz = b.z - a.z;
    return std::sqrt(dx * dx + dy * dy + dz * dz);
}

inline float length2D(const Vec3& v) { return std::sqrt(v.x * v.x + v.y * v.y); }

inline Vec3 normalize2D(const Vec3& v, const Vec3& fallback = {0.0f, 1.0f, 0.0f}) {
    const float len = length2D(v);
    if (len < 0.0001f) return fallback;
    return {v.x / len, v.y / len, 0.0f};
}

inline Vec3 rightFromForward(const Vec3& forward) {
    const Vec3 n = normalize2D(forward);
    return {n.y, -n.x, 0.0f};
}

inline Vec3 forwardFromHeading(float headingDeg) {
    const float r = degToRad(headingDeg);
    return {std::sin(r), std::cos(r), 0.0f};
}

inline Vec3 rotate2D(const Vec3& v, float degrees) {
    const float r = degToRad(degrees);
    const float c = std::cos(r);
    const float s = std::sin(r);
    return {v.x * c - v.y * s, v.x * s + v.y * c, v.z};
}

inline Vec3 pointBehind(const Vec3& origin, float headingDeg, float distance, float sideOffset = 0.0f) {
    const Vec3 forward = forwardFromHeading(headingDeg);
    const Vec3 right = rightFromForward(forward);
    return {
        origin.x - forward.x * distance + right.x * sideOffset,
        origin.y - forward.y * distance + right.y * sideOffset,
        origin.z
    };
}

inline Vec3 pointBehindView(const Vec3& origin, const Vec3& viewForward, float distance,
                            float angleOffsetDeg = 0.0f, float sideOffset = 0.0f) {
    const Vec3 f = normalize2D(rotate2D(normalize2D(viewForward), angleOffsetDeg));
    const Vec3 r = rightFromForward(f);
    return {
        origin.x - f.x * distance + r.x * sideOffset,
        origin.y - f.y * distance + r.y * sideOffset,
        origin.z
    };
}

inline Vec3 approach(const Vec3& from, const Vec3& to, float maxStep) {
    const float dx = to.x - from.x;
    const float dy = to.y - from.y;
    const float len = std::sqrt(dx * dx + dy * dy);
    if (len <= 0.0001f || maxStep <= 0.0f) return from;
    const float s = (len <= maxStep) ? 1.0f : (maxStep / len);
    return {from.x + dx * s, from.y + dy * s, from.z};
}

inline float headingTo(const Vec3& from, const Vec3& target) {
    float deg = radToDeg(std::atan2(target.x - from.x, target.y - from.y));
    if (deg < 0.0f) deg += 360.0f;
    return deg;
}

inline bool isWithinNightWindow(int hour, int startHour, int endHour) {
    if (startHour == endHour) return true;
    if (startHour < endHour) return hour >= startHour && hour < endHour;
    return hour >= startHour || hour < endHour;
}

inline bool nodeLooksPlausible(const Vec3& probe, const Vec3& node,
                               float maxHorizontalError, float maxVerticalError) {
    return distance2D(probe, node) <= maxHorizontalError &&
           std::fabs(node.z - probe.z) <= maxVerticalError;
}

inline bool stepLooksPlausible(const Vec3& from, const Vec3& to,
                               float requestedStep, float maxExtraSnap,
                               float maxVerticalDelta) {
    return distance2D(from, to) <= requestedStep + maxExtraSnap &&
           std::fabs(to.z - from.z) <= maxVerticalDelta;
}

inline void eyePair(const Vec3& watcher, float watcherHeading, float eyeHeight,
                    float halfSeparation, Vec3& left, Vec3& right) {
    const Vec3 facing = forwardFromHeading(watcherHeading);
    const Vec3 rightAxis = rightFromForward(facing);
    left = {
        watcher.x - rightAxis.x * halfSeparation,
        watcher.y - rightAxis.y * halfSeparation,
        watcher.z + eyeHeight
    };
    right = {
        watcher.x + rightAxis.x * halfSeparation,
        watcher.y + rightAxis.y * halfSeparation,
        watcher.z + eyeHeight
    };
}

inline float clamp01(float v) { return std::max(0.0f, std::min(1.0f, v)); }
inline float lerp(float a, float b, float t) { return a + (b - a) * clamp01(t); }

class FpsEma {
public:
    explicit FpsEma(float alpha = 0.10f) : alpha_(std::max(0.01f, std::min(1.0f, alpha))) {}

    void reset() { initialized_ = false; value_ = 0.0f; }

    float push(float sample) {
        if (sample <= 0.5f || sample > 1000.0f) return value_;
        if (!initialized_) {
            value_ = sample;
            initialized_ = true;
        } else {
            value_ += alpha_ * (sample - value_);
        }
        return value_;
    }

    bool ready() const { return initialized_; }
    float value() const { return value_; }

private:
    float alpha_ = 0.10f;
    float value_ = 0.0f;
    bool initialized_ = false;
};

template <std::size_t Capacity>
class BreadcrumbRing {
public:
    static_assert(Capacity > 1, "BreadcrumbRing capacity must be > 1");

    void clear() {
        head_ = 0;
        size_ = 0;
    }

    std::size_t size() const { return size_; }
    bool empty() const { return size_ == 0; }

    void push(const Breadcrumb& item) {
        items_[head_] = item;
        head_ = (head_ + 1) % Capacity;
        if (size_ < Capacity) ++size_;
    }

    // 0 = oldest, size()-1 = newest.
    const Breadcrumb& atChronological(std::size_t index) const {
        const std::size_t oldest = (head_ + Capacity - size_) % Capacity;
        return items_[(oldest + index) % Capacity];
    }

    const Breadcrumb* newest() const {
        if (size_ == 0) return nullptr;
        return &atChronological(size_ - 1);
    }

    const Breadcrumb* findClosestAge(std::uint32_t nowMs, std::uint32_t targetAgeMs,
                                     std::uint32_t toleranceMs, int interior) const {
        const Breadcrumb* best = nullptr;
        std::uint32_t bestDelta = 0xFFFFFFFFu;
        for (std::size_t i = 0; i < size_; ++i) {
            const Breadcrumb& b = atChronological(i);
            if (b.interior != interior) continue;
            const std::uint32_t age = nowMs - b.timeMs; // modulo-2^32 elapsed time
            if (age > 0x7FFFFFFFu) continue; // timestamp is actually in the future
            const std::uint32_t delta = age > targetAgeMs ? age - targetAgeMs : targetAgeMs - age;
            if (delta <= toleranceMs && delta < bestDelta) {
                best = &b;
                bestDelta = delta;
            }
        }
        return best;
    }

    std::size_t copyFromTime(std::uint32_t startTimeMs, int interior,
                             Breadcrumb* out, std::size_t outCapacity) const {
        if (!out || outCapacity == 0) return 0;
        std::size_t written = 0;
        for (std::size_t i = 0; i < size_ && written < outCapacity; ++i) {
            const Breadcrumb& b = atChronological(i);
            if (b.interior != interior) continue;
            if (static_cast<std::int32_t>(b.timeMs - startTimeMs) < 0) continue;
            out[written++] = b;
        }
        return written;
    }

private:
    std::array<Breadcrumb, Capacity> items_{};
    std::size_t head_ = 0;
    std::size_t size_ = 0;
};

} // namespace echo
