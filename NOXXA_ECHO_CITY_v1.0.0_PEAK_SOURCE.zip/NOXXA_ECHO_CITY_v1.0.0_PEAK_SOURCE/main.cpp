#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>
#include "isautils.h"
#include "sa_scripting.h"
#include "src/echo_core.h"
#include "src/director_logic.h"

#if !defined(IAML_VER) || IAML_VER < 01040000
#error "ECHO//CITY requires AML headers 1.4.0 or newer"
#endif

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <ctime>

MYMODCFG(dev.noxxa.gtasa.echocity, NOXXA ECHO CITY, 1.0.0, Henn)
NEEDGAME(com.rockstargames.gtasa)

BEGIN_DEPLIST()
    ADD_DEPENDENCY_VER(net.rusjj.aml, 1.4)
    ADD_DEPENDENCY_VER(net.rusjj.gtasa.utils, 1.4)
END_DEPLIST()

// SAUtils intentionally ships an incomplete opcode list. These are vanilla SA
// script commands used by the director. Keeping them here makes every pointer
// output auditable and prevents hidden memory-offset dependencies.
DEFOPCODE(056D, DOES_CHAR_EXIST, i);
DEFOPCODE(0665, GET_CHAR_MODEL, iv);
DEFOPCODE(068D, GET_ACTIVE_CAMERA_COORDINATES, vvv);
DEFOPCODE(068E, GET_ACTIVE_CAMERA_POINT_AT, vvv);
DEFOPCODE(06BD, IS_LINE_OF_SIGHT_CLEAR, ffffffbbbbb);
DEFOPCODE(077E, GET_AREA_VISIBLE, v);

ISAUtils* sautils = nullptr;
static void* gGTASA = nullptr;
static bool (*IsPlayerOnAMission)() = nullptr;

// IMPORTANT: every variable passed as an output pointer to ScriptCommand lives
// at static storage. SAUtils upstream fixed ARM64 stack corruption caused by
// passing pointers to short-lived stack variables through its script bridge.
static int gPlayer = 0;
static int gWanted = 0;
static int gHour = 0;
static int gMinute = 0;
static int gInterior = 0;
static int gPlayerModel = 0;
static float gPx = 0.0f, gPy = 0.0f, gPz = 0.0f, gPHeading = 0.0f;
static float gNodeX = 0.0f, gNodeY = 0.0f, gNodeZ = 0.0f;
static float gEntityX = 0.0f, gEntityY = 0.0f, gEntityZ = 0.0f;
static float gCamX = 0.0f, gCamY = 0.0f, gCamZ = 0.0f;
static float gCamAtX = 0.0f, gCamAtY = 0.0f, gCamAtZ = 0.0f;

struct DirectorConfig {
    bool enabled = true;
    bool nightOnly = true;
    bool redEyes = true;
    bool clonePlayerForEcho = true;
    bool useLineOfSight = true;
    bool requireMissionGuard = true;
    bool allowMultiplayer = false;

    int intensity = 1; // 0 subtle, 1 balanced, 2 nightmare
    int startHour = 21;
    int endHour = 5;
    int minFPS = 42;
    int watcherModelId = 7;
    int echoFallbackModelId = 7;

    int logicTickMs = 75;
    int visibilityTickMs = 40;
    int historyTickMs = 350;
    int watcherLifetimeSec = 44;
    int echoLifetimeSec = 30;
    int signalLifetimeSec = 28;

    int watcherBaseStepMs = 650;
    int echoStepMs = 340;
    int unseenGraceMs = 240;
    int stareChargeMs = 1500;

    float watcherSpawnDistance = 32.0f;
    float watcherBaseStepDistance = 2.55f;
    float watcherStopDistance = 6.2f;
    float nodeSnapRadius = 11.0f;
    float nodeVerticalTolerance = 5.5f;
    float stepSnapExtra = 2.8f;
};
static DirectorConfig C;

enum class ForceRequest : int {
    None = 0,
    Random,
    Watcher,
    Echo,
    Signal,
};

struct Runtime {
    echo::EventType active = echo::EventType::None;
    echo::EventType lastEvent = echo::EventType::None;
    ForceRequest force = ForceRequest::None;
    bool despawnRequested = false;
    bool multiplayerDetected = false;
    bool cameraValid = false;

    unsigned int nextAutoAt = 0;
    unsigned int lastLogicAt = 0;
    unsigned int lastVisibilityAt = 0;
    unsigned int lastHistoryAt = 0;
    unsigned int lowFpsSince = 0;

    unsigned int sessionWatcher = 0;
    unsigned int sessionEcho = 0;
    unsigned int sessionSignal = 0;
    unsigned int spawnRejects = 0;

    echo::Vec3 viewForward{0.0f, 1.0f, 0.0f};
    echo::FpsEma fps{0.12f};
};
static Runtime R;

struct WatcherState {
    int charRef = 0;
    int modelId = -1;
    bool ownsModel = false;
    bool visible = false;
    bool lastVisible = false;
    bool charged = false;
    bool finale = false;

    unsigned int spawnedAt = 0;
    unsigned int lastStepAt = 0;
    unsigned int visibleSince = 0;
    unsigned int unseenSince = 0;
    unsigned int finaleSeenAt = 0;
    int sightings = 0;
    int steps = 0;

    echo::Vec3 pos{};
    float heading = 0.0f;
    float closestDistance = 9999.0f;
};
static WatcherState W;

struct EchoState {
    static constexpr std::size_t kMaxPath = 48;

    int charRef = 0;
    int modelId = -1;
    bool ownsModel = false;
    bool visible = false;
    bool lastVisible = false;
    bool aware = false;

    unsigned int spawnedAt = 0;
    unsigned int lastStepAt = 0;
    unsigned int visibleSince = 0;
    unsigned int unseenSince = 0;

    echo::Breadcrumb path[kMaxPath]{};
    std::size_t pathCount = 0;
    std::size_t pathIndex = 0;
    echo::Vec3 pos{};
    float heading = 0.0f;
};
static EchoState E;

struct SignalState {
    echo::Vec3 pos{};
    bool visible = false;
    bool lastVisible = false;
    bool stareRegistered = false;
    bool pendingRelocate = false;
    int stage = 0;
    int sightings = 0;

    unsigned int spawnedAt = 0;
    unsigned int visibleSince = 0;
    unsigned int unseenSince = 0;
    unsigned int relocateAt = 0;
};
static SignalState S;

static echo::BreadcrumbRing<72> History;

static const char* kOffOn[] = {"FEM_OFF", "FEM_ON"};
static const char* kIntensityNames[] = {"SUBTLE", "BALANCED", "NIGHTMARE"};

static int clampi(int v, int lo, int hi) { return std::max(lo, std::min(hi, v)); }

static int randomInt(int lo, int hi) {
    if (hi <= lo) return lo;
    return lo + (std::rand() % (hi - lo + 1));
}

static float randomFloat(float lo, float hi) {
    if (hi <= lo) return lo;
    const float t = static_cast<float>(std::rand()) / static_cast<float>(RAND_MAX);
    return lo + (hi - lo) * t;
}

static void bindBool(const char* key, bool& value, const char* section = "Director") {
    ConfigEntry* e = cfg->Bind(key, value, section);
    value = e->GetBool();
    delete e;
}

static void bindInt(const char* key, int& value, int lo, int hi, const char* section = "Director") {
    ConfigEntry* e = cfg->Bind(key, value, section);
    e->Clamp(lo, hi);
    value = e->GetInt();
    delete e;
}

static void bindFloat(const char* key, float& value, float lo, float hi, const char* section = "Director") {
    ConfigEntry* e = cfg->Bind(key, value, section);
    e->Clamp(lo, hi);
    value = e->GetFloat();
    delete e;
}

static void LoadConfig() {
    bindBool("Enabled", C.enabled);
    bindBool("NightOnly", C.nightOnly);
    bindBool("RedEyes", C.redEyes);
    bindBool("ClonePlayerForEcho", C.clonePlayerForEcho);
    bindBool("UseLineOfSight", C.useLineOfSight);
    bindBool("RequireMissionGuard", C.requireMissionGuard);
    bindBool("AllowMultiplayer", C.allowMultiplayer);

    bindInt("Intensity", C.intensity, 0, 2);
    bindInt("StartHour", C.startHour, 0, 23);
    bindInt("EndHour", C.endHour, 0, 23);
    bindInt("MinFPS", C.minFPS, 0, 240);
    bindInt("WatcherModelId", C.watcherModelId, 7, 288);
    bindInt("EchoFallbackModelId", C.echoFallbackModelId, 7, 288);
    bindInt("LogicTickMs", C.logicTickMs, 32, 300);
    bindInt("VisibilityTickMs", C.visibilityTickMs, 20, 200);
    bindInt("HistoryTickMs", C.historyTickMs, 200, 1000);
    bindInt("WatcherLifetimeSec", C.watcherLifetimeSec, 10, 180);
    bindInt("EchoLifetimeSec", C.echoLifetimeSec, 10, 180);
    bindInt("SignalLifetimeSec", C.signalLifetimeSec, 8, 120);
    bindInt("WatcherBaseStepMs", C.watcherBaseStepMs, 180, 3000);
    bindInt("EchoStepMs", C.echoStepMs, 180, 1500);
    bindInt("UnseenGraceMs", C.unseenGraceMs, 80, 1500);
    bindInt("StareChargeMs", C.stareChargeMs, 500, 5000);

    bindFloat("WatcherSpawnDistance", C.watcherSpawnDistance, 16.0f, 70.0f);
    bindFloat("WatcherBaseStepDistance", C.watcherBaseStepDistance, 0.8f, 8.0f);
    bindFloat("WatcherStopDistance", C.watcherStopDistance, 3.0f, 18.0f);
    bindFloat("NodeSnapRadius", C.nodeSnapRadius, 3.0f, 25.0f);
    bindFloat("NodeVerticalTolerance", C.nodeVerticalTolerance, 2.0f, 12.0f);
    bindFloat("StepSnapExtra", C.stepSnapExtra, 0.5f, 8.0f);

    if (C.watcherStopDistance >= C.watcherSpawnDistance - 4.0f) {
        C.watcherStopDistance = C.watcherSpawnDistance * 0.25f;
    }
    cfg->Save();
}

static void SaveBool(const char* key, bool value) {
    ConfigEntry* e = cfg->Bind(key, value, "Director");
    e->SetBool(value);
    delete e;
    cfg->Save();
}

static void SaveInt(const char* key, int value) {
    ConfigEntry* e = cfg->Bind(key, value, "Director");
    e->SetInt(value);
    delete e;
    cfg->Save();
}

static echo::Intensity CurrentIntensity() {
    return static_cast<echo::Intensity>(echo::clampIntensity(C.intensity));
}

static void ScheduleNext(unsigned int now) {
    const echo::IntensityProfile p = echo::profileFor(CurrentIntensity());
    const int sec = randomInt(p.cooldownMinSec, p.cooldownMaxSec);
    R.nextAutoAt = echo::scheduleAfterSeconds(now, sec);
}

static bool DetectMultiplayer() {
    return aml->GetLibHandle("libsamp.so") != nullptr ||
           aml->GetLibHandle("libvoice.so") != nullptr ||
           aml->GetLibHandle("libAlyn_SAMPMOBILE.so") != nullptr ||
           aml->GetLibHandle("libSAMP.so") != nullptr ||
           aml->HasMod("net.rusjj.resamp");
}

static bool RefreshCameraSnapshot() {
    gCamX = gCamY = gCamZ = 0.0f;
    gCamAtX = gCamAtY = gCamAtZ = 0.0f;
    CALLSCM(GET_ACTIVE_CAMERA_COORDINATES, &gCamX, &gCamY, &gCamZ);
    CALLSCM(GET_ACTIVE_CAMERA_POINT_AT, &gCamAtX, &gCamAtY, &gCamAtZ);

    echo::Vec3 raw{gCamAtX - gCamX, gCamAtY - gCamY, 0.0f};
    if (echo::length2D(raw) < 0.05f) {
        R.viewForward = echo::forwardFromHeading(gPHeading);
        R.cameraValid = false;
        return false;
    }
    R.viewForward = echo::normalize2D(raw);
    R.cameraValid = true;
    return true;
}

static bool RefreshPlayerSnapshot() {
    CALLSCM(GET_PLAYER_CHAR, 0, &gPlayer);
    if (gPlayer <= 0 || !CALLSCM(DOES_CHAR_EXIST, gPlayer)) return false;
    if (CALLSCM(IS_CHAR_DEAD, gPlayer)) return false;

    CALLSCM(GET_CHAR_COORDINATES, gPlayer, &gPx, &gPy, &gPz);
    CALLSCM(GET_CHAR_HEADING, gPlayer, &gPHeading);
    CALLSCM(GET_TIME_OF_DAY, &gHour, &gMinute);
    CALLSCM(STORE_WANTED_LEVEL, 0, &gWanted);
    CALLSCM(GET_AREA_VISIBLE, &gInterior);
    CALLSCM(GET_CHAR_MODEL, gPlayer, &gPlayerModel);
    RefreshCameraSnapshot();
    return true;
}

static bool IsNight() {
    if (!C.nightOnly) return true;
    return echo::isWithinNightWindow(gHour, C.startHour, C.endHour);
}

static bool MissionGuardPasses(bool manual) {
    if (!C.requireMissionGuard) return true;
    if (!IsPlayerOnAMission) return manual; // Manual diagnostics are still possible on stripped builds.
    return !IsPlayerOnAMission();
}

static bool CommonSafetyPasses(bool manual, bool signalEvent = false) {
    if (!RefreshPlayerSnapshot()) return false;
    if (R.multiplayerDetected && !C.allowMultiplayer) return false;
    if (CALLSCM(IS_CHAR_IN_ANY_CAR, gPlayer)) return false;
    if (gWanted > 0) return false;
    if (gInterior != 0) return false; // v1 intentionally refuses GTA's separate interior worlds.
    if (!MissionGuardPasses(manual)) return false;
    if (!manual && !IsNight()) return false;

    const float fps = R.fps.ready() ? R.fps.value() : sautils->GetCurrentFPS();
    if (!manual && C.minFPS > 0 && fps > 1.0f) {
        const float threshold = signalEvent ? static_cast<float>(C.minFPS) * 0.72f
                                            : static_cast<float>(C.minFPS);
        if (fps < threshold) return false;
    }
    return true;
}

static bool FindPlausibleNode(const echo::Vec3& probe, echo::Vec3& out) {
    gNodeX = gNodeY = gNodeZ = 0.0f;
    CALLSCM(GET_CLOSEST_CHAR_NODE, probe.x, probe.y, probe.z, &gNodeX, &gNodeY, &gNodeZ);
    out = {gNodeX, gNodeY, gNodeZ};
    return echo::nodeLooksPlausible(probe, out, C.nodeSnapRadius, C.nodeVerticalTolerance);
}

static bool IsAreaOccupiedAt(const echo::Vec3& p, bool includeCharacters = true) {
    constexpr float r = 0.8f;
    return CALLSCM(IS_AREA_OCCUPIED,
                   p.x - r, p.y - r, p.z - 0.6f,
                   p.x + r, p.y + r, p.z + 2.2f,
                   true, true, includeCharacters, true, false) != 0;
}

static bool IsLineClear(const echo::Vec3& from, const echo::Vec3& to) {
    if (!C.useLineOfSight) return true;
    return CALLSCM(IS_LINE_OF_SIGHT_CLEAR,
                   from.x, from.y, from.z,
                   to.x, to.y, to.z,
                   true, true, false, true, false) != 0;
}

static bool PointActuallyVisible(const echo::Vec3& p, float radius) {
    if (!CALLSCM(IS_POINT_ON_SCREEN, p.x, p.y, p.z, radius)) return false;
    if (!C.useLineOfSight || !R.cameraValid) return true;
    const echo::Vec3 cam{gCamX, gCamY, gCamZ};
    return IsLineClear(cam, p);
}

static bool PedActuallyVisible(int charRef, const echo::Vec3& pos) {
    if (charRef <= 0 || !CALLSCM(DOES_CHAR_EXIST, charRef)) return false;
    const echo::Vec3 chest{pos.x, pos.y, pos.z + 1.05f};
    // IS_CHAR_ON_SCREEN is a cheap first gate. The point/LOS test prevents
    // movement while the player is actually looking at the entity.
    if (!CALLSCM(IS_CHAR_ON_SCREEN, charRef) &&
        !CALLSCM(IS_POINT_ON_SCREEN, chest.x, chest.y, chest.z, 0.9f)) return false;
    return PointActuallyVisible(chest, 0.95f);
}

static bool FindSpawnNode(float minDistance, float maxDistance, echo::Vec3& out,
                          const echo::Vec3* preferred = nullptr) {
    static const float kAngles[] = {0.0f, 18.0f, -18.0f, 35.0f, -35.0f, 55.0f, -55.0f, 78.0f, -78.0f};
    const echo::Vec3 player{gPx, gPy, gPz};

    for (int attempt = 0; attempt < 12; ++attempt) {
        echo::Vec3 probe{};
        if (preferred && attempt < 4) {
            probe = *preferred;
            const float jitter = static_cast<float>(attempt) * 1.2f;
            probe.x += (attempt & 1) ? jitter : -jitter;
            probe.y += (attempt & 2) ? jitter : -jitter;
        } else {
            const float angle = kAngles[randomInt(0, static_cast<int>(sizeof(kAngles) / sizeof(kAngles[0])) - 1)] +
                                randomFloat(-7.0f, 7.0f);
            const float dist = randomFloat(minDistance, maxDistance);
            const float side = randomFloat(-3.0f, 3.0f);
            probe = echo::pointBehindView(player, R.viewForward, dist, angle, side);
        }

        echo::Vec3 node{};
        if (!FindPlausibleNode(probe, node)) continue;
        node.z += 0.35f;

        const float actualDistance = echo::distance2D(player, node);
        if (!preferred && (actualDistance < minDistance * 0.75f || actualDistance > maxDistance + C.nodeSnapRadius)) continue;
        if (IsAreaOccupiedAt(node)) continue;
        if (PointActuallyVisible({node.x, node.y, node.z + 1.0f}, 0.9f)) continue;

        out = node;
        return true;
    }
    ++R.spawnRejects;
    return false;
}

static bool LoadPedModel(int modelId) {
    CALLSCM(REQUEST_MODEL, modelId);
    CALLSCM(LOAD_ALL_MODELS_NOW);
    return CALLSCM(HAS_MODEL_LOADED, modelId) != 0;
}

static bool SpawnPedAt(int modelId, const echo::Vec3& pos, int& outRef) {
    outRef = 0;
    CALLSCM(CREATE_CHAR, 4, modelId, pos.x, pos.y, pos.z, &outRef);
    if (outRef <= 0 || !CALLSCM(DOES_CHAR_EXIST, outRef)) return false;

    CALLSCM(SET_CHAR_STAY_IN_SAME_PLACE, outRef, true);
    CALLSCM(SET_CHAR_HEALTH, outRef, 1000);
    CALLSCM(SET_CHAR_PROOFS, outRef, true, true, true, true, true);
    CALLSCM(SET_CHAR_SUFFERS_CRITICAL_HITS, outRef, false);
    CALLSCM(SET_CHAR_DROPS_WEAPONS_WHEN_DEAD, outRef, false);
    return true;
}

static void DeletePed(int& charRef, int modelId, bool ownsModel) {
    if (charRef > 0 && CALLSCM(DOES_CHAR_EXIST, charRef)) {
        CALLSCM(DELETE_CHAR, charRef);
    }
    charRef = 0;
    if (ownsModel && modelId >= 0) CALLSCM(MARK_MODEL_AS_NO_LONGER_NEEDED, modelId);
}

static void DrawEyesAt(const echo::Vec3& pos, float heading, unsigned int now,
                       int red, int green, int blue, float baseRadius, bool intense = false) {
    if (!C.redEyes) return;
    echo::Vec3 left{}, right{};
    echo::eyePair(pos, heading, 1.61f, 0.075f, left, right);
    const float pulse = 0.5f + 0.5f * std::sin(static_cast<float>(now % 2000u) * 0.0105f);
    const float radius = baseRadius + pulse * (intense ? 0.018f : 0.009f);
    CALLSCM(DRAW_CORONA, left.x, left.y, left.z, radius, 2, 0, red, green, blue);
    CALLSCM(DRAW_CORONA, right.x, right.y, right.z, radius, 2, 0, red, green, blue);
}

static const char* EventName(echo::EventType type) {
    switch (type) {
        case echo::EventType::Watcher: return "WATCHER";
        case echo::EventType::Echo: return "ECHO";
        case echo::EventType::Signal: return "SIGNAL";
        default: return "NONE";
    }
}

static void CleanupActive(const char* reason) {
    const echo::EventType ended = R.active;
    if (ended == echo::EventType::Watcher) {
        DeletePed(W.charRef, W.modelId, W.ownsModel);
        W = WatcherState{};
    } else if (ended == echo::EventType::Echo) {
        DeletePed(E.charRef, E.modelId, E.ownsModel);
        E = EchoState{};
    } else if (ended == echo::EventType::Signal) {
        S = SignalState{};
    }

    if (ended != echo::EventType::None) {
        logger->Info("%s cleanup: %s", EventName(ended), reason ? reason : "unknown");
        R.lastEvent = ended;
    }
    R.active = echo::EventType::None;
    R.lowFpsSince = 0;
    R.despawnRequested = false;
    ScheduleNext(sautils ? sautils->GetCurrentMs() : 0u);
}

static void FacePedToPlayer(int charRef, const echo::Vec3& pos, float& headingOut) {
    headingOut = echo::headingTo(pos, {gPx, gPy, gPz});
    if (charRef > 0 && CALLSCM(DOES_CHAR_EXIST, charRef)) {
        CALLSCM(SET_CHAR_HEADING, charRef, headingOut);
    }
}

static bool SpawnWatcher(bool manual) {
    if (!CommonSafetyPasses(manual, false)) return false;

    echo::Vec3 node{};
    const float base = C.watcherSpawnDistance;
    if (!FindSpawnNode(base - 4.0f, base + 8.0f, node)) return false;
    if (!LoadPedModel(C.watcherModelId)) {
        logger->Print(LogP_Warn, "WATCHER model %d failed to load", C.watcherModelId);
        return false;
    }

    W = WatcherState{};
    W.modelId = C.watcherModelId;
    W.ownsModel = true;
    W.pos = node;
    if (!SpawnPedAt(W.modelId, W.pos, W.charRef)) {
        CALLSCM(MARK_MODEL_AS_NO_LONGER_NEEDED, W.modelId);
        W = WatcherState{};
        return false;
    }

    const unsigned int now = sautils->GetCurrentMs();
    W.spawnedAt = W.lastStepAt = now;
    W.unseenSince = now;
    W.closestDistance = echo::distance2D(W.pos, {gPx, gPy, gPz});
    FacePedToPlayer(W.charRef, W.pos, W.heading);

    R.active = echo::EventType::Watcher;
    ++R.sessionWatcher;
    logger->Info("WATCHER spawned %.1fm away (manual=%d)", W.closestDistance, manual ? 1 : 0);
    return true;
}

static bool EchoHistoryReady(unsigned int now) {
    if (History.size() < 18) return false;
    const echo::Breadcrumb& oldest = History.atChronological(0);
    const unsigned int age = now - oldest.timeMs; // wrap-safe for our short history window
    return age >= 7000u && age < 60000u;
}

static bool IsCloneSafeModel(int modelId) {
    // CJ (0) and special-character slots are intentionally excluded. Normal
    // pedestrian models are much less likely to carry player-only assumptions.
    return modelId >= 7 && modelId <= 288;
}

static bool SpawnEcho(bool manual) {
    if (!CommonSafetyPasses(manual, false)) return false;
    const unsigned int now = sautils->GetCurrentMs();
    if (!EchoHistoryReady(now)) {
        logger->Info("ECHO skipped: movement history not ready");
        return false;
    }

    const unsigned int targetAge = static_cast<unsigned int>(randomInt(8500, 14500));
    const echo::Breadcrumb* seed = History.findClosestAge(now, targetAge, 3200u, 0);
    if (!seed) return false;
    const float seedDistance = echo::distance2D(seed->pos, {gPx, gPy, gPz});
    if (seedDistance < 10.0f || seedDistance > 65.0f) return false;

    echo::Vec3 spawnNode{};
    if (!FindSpawnNode(10.0f, 60.0f, spawnNode, &seed->pos)) return false;

    E = EchoState{};
    const bool clone = C.clonePlayerForEcho && IsCloneSafeModel(gPlayerModel) &&
                       CALLSCM(HAS_MODEL_LOADED, gPlayerModel);
    E.modelId = clone ? gPlayerModel : C.echoFallbackModelId;
    E.ownsModel = !clone;
    if (E.ownsModel && !LoadPedModel(E.modelId)) {
        E = EchoState{};
        return false;
    }

    E.pathCount = History.copyFromTime(seed->timeMs, 0, E.path, EchoState::kMaxPath);
    if (E.pathCount < 4) {
        if (E.ownsModel) CALLSCM(MARK_MODEL_AS_NO_LONGER_NEEDED, E.modelId);
        E = EchoState{};
        return false;
    }

    E.pos = spawnNode;
    if (!SpawnPedAt(E.modelId, E.pos, E.charRef)) {
        if (E.ownsModel) CALLSCM(MARK_MODEL_AS_NO_LONGER_NEEDED, E.modelId);
        E = EchoState{};
        return false;
    }

    E.spawnedAt = E.lastStepAt = now;
    E.unseenSince = now;
    E.pathIndex = 0;
    E.heading = E.path[0].heading;
    CALLSCM(SET_CHAR_HEADING, E.charRef, E.heading);

    R.active = echo::EventType::Echo;
    ++R.sessionEcho;
    logger->Info("ECHO spawned using model %d (%s), history=%u samples",
                 E.modelId, clone ? "player-clone" : "fallback",
                 static_cast<unsigned int>(E.pathCount));
    return true;
}

static bool SignalDistanceForStage(int stage, float& minDistance, float& maxDistance) {
    switch (stage) {
        case 0: minDistance = 38.0f; maxDistance = 52.0f; return true;
        case 1: minDistance = 27.0f; maxDistance = 36.0f; return true;
        case 2: minDistance = 16.0f; maxDistance = 24.0f; return true;
        case 3: minDistance = 8.0f; maxDistance = 13.0f; return true;
        default: return false;
    }
}

static bool PlaceSignalStage(int stage) {
    float minD = 0.0f, maxD = 0.0f;
    if (!SignalDistanceForStage(stage, minD, maxD)) return false;
    echo::Vec3 node{};
    if (!FindSpawnNode(minD, maxD, node)) return false;
    S.pos = node;
    S.stage = stage;
    S.visible = S.lastVisible = false;
    S.stareRegistered = false;
    S.pendingRelocate = false;
    S.visibleSince = 0;
    S.unseenSince = sautils->GetCurrentMs();
    return true;
}

static bool SpawnSignal(bool manual) {
    if (!CommonSafetyPasses(manual, true)) return false;
    S = SignalState{};
    if (!PlaceSignalStage(0)) return false;
    S.spawnedAt = sautils->GetCurrentMs();
    R.active = echo::EventType::Signal;
    ++R.sessionSignal;
    logger->Info("SIGNAL spawned (manual=%d)", manual ? 1 : 0);
    return true;
}

static bool StartEvent(echo::EventType type, bool manual) {
    if (R.active != echo::EventType::None) return true;
    switch (type) {
        case echo::EventType::Watcher: return SpawnWatcher(manual);
        case echo::EventType::Echo: return SpawnEcho(manual);
        case echo::EventType::Signal: return SpawnSignal(manual);
        default: return false;
    }
}

static void CaptureHistory(unsigned int now) {
    if (now - R.lastHistoryAt < static_cast<unsigned int>(C.historyTickMs)) return;
    R.lastHistoryAt = now;

    if (gInterior != 0 || gWanted > 0 || CALLSCM(IS_CHAR_IN_ANY_CAR, gPlayer)) return;
    const echo::Breadcrumb* newest = History.newest();
    const echo::Vec3 current{gPx, gPy, gPz};
    if (newest) {
        const float moved = echo::distance2D(newest->pos, current);
        if (moved < 0.45f && now - newest->timeMs < 900u) return;
        if (std::fabs(newest->pos.z - current.z) > 10.0f) {
            // Teleport/load transition: reset so ECHO never replays a discontinuity.
            History.clear();
        }
    }
    History.push({current, gPHeading, now, gInterior});
}

static void UpdateVisibilityState(bool visible, bool& lastVisible, bool& currentVisible,
                                  unsigned int now, unsigned int& visibleSince,
                                  unsigned int& unseenSince) {
    currentVisible = visible;
    if (visible && !lastVisible) {
        visibleSince = now;
        unseenSince = 0;
    } else if (!visible && lastVisible) {
        unseenSince = now;
        visibleSince = 0;
    } else if (visible && visibleSince == 0) {
        visibleSince = now;
    } else if (!visible && unseenSince == 0) {
        unseenSince = now;
    }
    lastVisible = visible;
}

static void RefreshWatcherVisibility(unsigned int now) {
    if (R.active != echo::EventType::Watcher || W.charRef <= 0) return;
    if (!CALLSCM(DOES_CHAR_EXIST, W.charRef)) {
        CleanupActive("entity handle vanished");
        return;
    }
    CALLSCM(GET_CHAR_COORDINATES, W.charRef, &gEntityX, &gEntityY, &gEntityZ);
    W.pos = {gEntityX, gEntityY, gEntityZ};

    const bool before = W.visible;
    const bool visible = PedActuallyVisible(W.charRef, W.pos);
    UpdateVisibilityState(visible, W.lastVisible, W.visible, now, W.visibleSince, W.unseenSince);
    if (visible && !before) ++W.sightings;
    if (visible && W.visibleSince != 0 && now - W.visibleSince >= static_cast<unsigned int>(C.stareChargeMs)) {
        W.charged = true;
    }
}

static void RefreshEchoVisibility(unsigned int now) {
    if (R.active != echo::EventType::Echo || E.charRef <= 0) return;
    if (!CALLSCM(DOES_CHAR_EXIST, E.charRef)) {
        CleanupActive("entity handle vanished");
        return;
    }
    CALLSCM(GET_CHAR_COORDINATES, E.charRef, &gEntityX, &gEntityY, &gEntityZ);
    E.pos = {gEntityX, gEntityY, gEntityZ};

    const bool before = E.visible;
    const bool visible = PedActuallyVisible(E.charRef, E.pos);
    UpdateVisibilityState(visible, E.lastVisible, E.visible, now, E.visibleSince, E.unseenSince);

    if (visible && E.visibleSince != 0 && now - E.visibleSince > 1200u) {
        E.aware = true;
        FacePedToPlayer(E.charRef, E.pos, E.heading);
    }
    if (!visible && before && E.aware) {
        CleanupActive("it noticed the player, then vanished");
    }
}

static void RefreshSignalVisibility(unsigned int now) {
    if (R.active != echo::EventType::Signal) return;
    const echo::Vec3 eyeCenter{S.pos.x, S.pos.y, S.pos.z + 1.61f};
    const bool before = S.visible;
    const bool visible = PointActuallyVisible(eyeCenter, 0.75f);
    UpdateVisibilityState(visible, S.lastVisible, S.visible, now, S.visibleSince, S.unseenSince);

    if (visible && S.visibleSince != 0 && now - S.visibleSince > 650u) {
        S.stareRegistered = true;
    }
    if (!visible && before && S.stareRegistered) {
        ++S.sightings;
        if (S.stage >= 3) {
            CleanupActive("final sighting complete");
            return;
        }
        S.pendingRelocate = true;
        S.relocateAt = echo::scheduleAfterMs(now, static_cast<unsigned int>(randomInt(450, 900)));
    }
}

static void RefreshActiveVisibility(unsigned int now) {
    if (now - R.lastVisibilityAt < static_cast<unsigned int>(C.visibilityTickMs)) return;
    R.lastVisibilityAt = now;
    RefreshCameraSnapshot();

    if (R.active == echo::EventType::Watcher) RefreshWatcherVisibility(now);
    else if (R.active == echo::EventType::Echo) RefreshEchoVisibility(now);
    else if (R.active == echo::EventType::Signal) RefreshSignalVisibility(now);
}

static bool TryWatcherStep(unsigned int now) {
    if (W.visible || W.finale || W.charRef <= 0) return false;
    if (W.unseenSince == 0 || now - W.unseenSince < static_cast<unsigned int>(C.unseenGraceMs)) return false;

    const echo::IntensityProfile profile = echo::profileFor(CurrentIntensity());
    const float sightingSpeed = 1.0f + std::min(0.40f, static_cast<float>(W.sightings) * 0.055f);
    const float chargeBonus = W.charged ? 1.45f : 1.0f;
    const float stepDistance = C.watcherBaseStepDistance * profile.watcherStepScale * sightingSpeed * chargeBonus;
    const float intervalScale = std::max(0.65f, 1.0f - static_cast<float>(W.sightings) * 0.035f);
    const unsigned int interval = static_cast<unsigned int>(
        std::max(160.0f, static_cast<float>(C.watcherBaseStepMs) * profile.watcherIntervalScale * intervalScale));
    if (now - W.lastStepAt < interval) return false;
    W.lastStepAt = now;

    const echo::Vec3 player{gPx, gPy, gPz};
    const float distance = echo::distance2D(W.pos, player);
    W.closestDistance = std::min(W.closestDistance, distance);
    if (distance <= C.watcherStopDistance) {
        W.finale = true;
        FacePedToPlayer(W.charRef, W.pos, W.heading);
        return false;
    }

    const float allowed = std::min(stepDistance, std::max(0.6f, distance - C.watcherStopDistance));
    const echo::Vec3 direct = echo::approach(W.pos, player, allowed);
    const echo::Vec3 toward = echo::normalize2D({player.x - W.pos.x, player.y - W.pos.y, 0.0f});
    const echo::Vec3 side = echo::rightFromForward(toward);

    for (int attempt = 0; attempt < 3; ++attempt) {
        echo::Vec3 probe = direct;
        if (attempt == 1) {
            probe.x += side.x * 1.25f;
            probe.y += side.y * 1.25f;
        } else if (attempt == 2) {
            probe.x -= side.x * 1.25f;
            probe.y -= side.y * 1.25f;
        }
        probe.z = W.pos.z;

        echo::Vec3 node{};
        if (!FindPlausibleNode(probe, node)) continue;
        node.z += 0.35f;
        if (!echo::stepLooksPlausible(W.pos, node, allowed, C.stepSnapExtra, C.nodeVerticalTolerance)) continue;
        if (PointActuallyVisible({node.x, node.y, node.z + 1.0f}, 0.85f)) continue;
        if (!IsLineClear({W.pos.x, W.pos.y, W.pos.z + 0.8f}, {node.x, node.y, node.z + 0.8f})) continue;
        // Ignore characters here so the Watcher does not count its own nearby
        // collision volume as an occupied destination during short finale steps.
        if (IsAreaOccupiedAt(node, false)) continue;

        CALLSCM(SET_CHAR_COORDINATES, W.charRef, node.x, node.y, node.z);
        W.pos = node;
        ++W.steps;
        W.charged = false;
        FacePedToPlayer(W.charRef, W.pos, W.heading);
        return true;
    }
    return false;
}

static void TickWatcher(unsigned int now) {
    if (W.charRef <= 0 || !CALLSCM(DOES_CHAR_EXIST, W.charRef)) {
        CleanupActive("watcher no longer exists");
        return;
    }
    if (CALLSCM(IS_CHAR_DEAD, W.charRef)) {
        CleanupActive("watcher died unexpectedly");
        return;
    }
    if (now - W.spawnedAt > static_cast<unsigned int>(C.watcherLifetimeSec * 1000)) {
        CleanupActive("lifetime expired");
        return;
    }

    if (W.finale) {
        FacePedToPlayer(W.charRef, W.pos, W.heading);
        if (W.visible) {
            if (W.finaleSeenAt == 0) W.finaleSeenAt = now;
            if (now - W.finaleSeenAt > 900u) {
                CleanupActive("finale witnessed");
            }
        }
        return;
    }

    FacePedToPlayer(W.charRef, W.pos, W.heading);
    TryWatcherStep(now);
}

static void TickEcho(unsigned int now) {
    if (E.charRef <= 0 || !CALLSCM(DOES_CHAR_EXIST, E.charRef)) {
        CleanupActive("echo no longer exists");
        return;
    }
    if (CALLSCM(IS_CHAR_DEAD, E.charRef)) {
        CleanupActive("echo died unexpectedly");
        return;
    }
    if (now - E.spawnedAt > static_cast<unsigned int>(C.echoLifetimeSec * 1000)) {
        CleanupActive("lifetime expired");
        return;
    }
    if (E.visible || E.aware) return;
    if (E.unseenSince == 0 || now - E.unseenSince < static_cast<unsigned int>(C.unseenGraceMs)) return;
    if (now - E.lastStepAt < static_cast<unsigned int>(C.echoStepMs)) return;
    E.lastStepAt = now;

    if (E.pathIndex + 1 >= E.pathCount) {
        CleanupActive("finished replaying the player's route");
        return;
    }

    // Skip tiny history samples but never jump across a large discontinuity.
    std::size_t nextIndex = E.pathIndex + 1;
    while (nextIndex + 1 < E.pathCount &&
           echo::distance2D(E.path[E.pathIndex].pos, E.path[nextIndex].pos) < 0.35f) {
        ++nextIndex;
    }
    const echo::Breadcrumb& target = E.path[nextIndex];
    if (target.interior != 0 || echo::distance2D(E.pos, target.pos) > 8.5f ||
        std::fabs(E.pos.z - target.pos.z) > 7.0f) {
        CleanupActive("history discontinuity rejected");
        return;
    }

    echo::Vec3 node{};
    if (!FindPlausibleNode(target.pos, node)) {
        ++E.pathIndex; // a single bad breadcrumb should not stall the whole encounter
        return;
    }
    node.z += 0.35f;
    if (PointActuallyVisible({node.x, node.y, node.z + 1.0f}, 0.85f)) return;
    if (!echo::stepLooksPlausible(E.pos, node, 6.0f, 2.5f, 6.0f)) {
        CleanupActive("echo step rejected");
        return;
    }
    if (!IsLineClear({E.pos.x, E.pos.y, E.pos.z + 0.8f}, {node.x, node.y, node.z + 0.8f})) return;

    CALLSCM(SET_CHAR_COORDINATES, E.charRef, node.x, node.y, node.z);
    E.pos = node;
    E.pathIndex = nextIndex;
    E.heading = target.heading;
    CALLSCM(SET_CHAR_HEADING, E.charRef, E.heading);

    if (echo::distance2D(E.pos, {gPx, gPy, gPz}) < 4.5f) {
        CleanupActive("echo caught up while unseen");
    }
}

static void TickSignal(unsigned int now) {
    if (now - S.spawnedAt > static_cast<unsigned int>(C.signalLifetimeSec * 1000)) {
        CleanupActive("lifetime expired");
        return;
    }

    if (S.pendingRelocate && !S.visible && echo::timeReached(now, S.relocateAt)) {
        const int nextStage = S.stage + 1;
        if (!PlaceSignalStage(nextStage)) {
            CleanupActive("could not find a hidden relocation point");
        }
        return;
    }

    if (S.stage >= 3 && S.visible && S.visibleSince != 0 && now - S.visibleSince > 1200u) {
        CleanupActive("final signal held eye contact");
    }
}

static bool SafetyChangedDuringEvent() {
    if (!RefreshPlayerSnapshot()) return true;
    if (R.multiplayerDetected && !C.allowMultiplayer) return true;
    if (CALLSCM(IS_CHAR_IN_ANY_CAR, gPlayer)) return true;
    if (gWanted > 0 || gInterior != 0) return true;
    if (C.requireMissionGuard && IsPlayerOnAMission && IsPlayerOnAMission()) return true;
    return false;
}

static bool PerformanceWatchdog(unsigned int now) {
    const float fps = R.fps.value();
    if (R.active == echo::EventType::Signal || C.minFPS <= 0 || !R.fps.ready()) {
        R.lowFpsSince = 0;
        return false;
    }

    const float severe = static_cast<float>(C.minFPS) * 0.68f;
    if (fps > 1.0f && fps < severe) {
        if (R.lowFpsSince == 0) R.lowFpsSince = now;
        if (now - R.lowFpsSince > 1500u) {
            CleanupActive("sustained FPS budget violation");
            return true;
        }
    } else {
        R.lowFpsSince = 0;
    }
    return false;
}

static void DrawActive(unsigned int now) {
    if (!C.redEyes) return;
    if (R.active == echo::EventType::Watcher && W.visible) {
        DrawEyesAt(W.pos, W.heading, now, 255, 22, 22, W.finale ? 0.068f : 0.047f, W.finale);
    } else if (R.active == echo::EventType::Echo && E.visible) {
        DrawEyesAt(E.pos, E.heading, now, 135, 165, 255, 0.038f, E.aware);
    } else if (R.active == echo::EventType::Signal && S.visible) {
        const float heading = echo::headingTo(S.pos, {gPx, gPy, gPz});
        const float stageBoost = 0.006f * static_cast<float>(S.stage);
        DrawEyesAt(S.pos, heading, now, 255, 18, 18, 0.052f + stageBoost, S.stage >= 2);
    }
}

static echo::EventType PickAutomaticEvent(unsigned int now) {
    const bool echoReady = EchoHistoryReady(now);
    const float avg = R.fps.ready() ? R.fps.value() : sautils->GetCurrentFPS();
    const bool tightBudget = C.minFPS > 0 && avg > 1.0f && avg < static_cast<float>(C.minFPS) * 1.08f;
    return echo::chooseWeightedEvent(randomInt(0, 99), CurrentIntensity(), R.lastEvent, echoReady, tightBudget);
}

static bool ProcessForceRequest() {
    if (R.force == ForceRequest::None) return false;
    const ForceRequest request = R.force;
    R.force = ForceRequest::None;
    if (R.active != echo::EventType::None) CleanupActive("replaced by manual force request");

    echo::EventType type = echo::EventType::None;
    if (request == ForceRequest::Watcher) type = echo::EventType::Watcher;
    else if (request == ForceRequest::Echo) type = echo::EventType::Echo;
    else if (request == ForceRequest::Signal) type = echo::EventType::Signal;
    else if (request == ForceRequest::Random) type = PickAutomaticEvent(sautils->GetCurrentMs());

    if (!StartEvent(type, true)) {
        logger->Info("Manual %s request refused by safety/history/spawn checks", EventName(type));
        return false;
    }
    return true;
}

static void OnPlayerUpdate(uintptr_t) {
    if (!sautils) return;
    const unsigned int now = sautils->GetCurrentMs();

    // Rendering is intentionally tiny: at most two coronas. Visibility itself
    // is throttled; this keeps 120 Hz gameplay from turning into 120 LOS tests/s.
    DrawActive(now);
    RefreshActiveVisibility(now);

    if (now - R.lastLogicAt < static_cast<unsigned int>(C.logicTickMs)) return;
    R.lastLogicAt = now;
    R.fps.push(sautils->GetCurrentFPS());

    if (!RefreshPlayerSnapshot()) {
        if (R.active != echo::EventType::None) CleanupActive("player unavailable");
        return;
    }
    CaptureHistory(now);

    if (R.despawnRequested) {
        if (R.active != echo::EventType::None) CleanupActive("manual despawn");
        R.despawnRequested = false;
    }
    ProcessForceRequest();

    if (R.active != echo::EventType::None) {
        if (SafetyChangedDuringEvent()) {
            CleanupActive("game safety state changed");
            return;
        }
        if (PerformanceWatchdog(now)) return;

        if (R.active == echo::EventType::Watcher) TickWatcher(now);
        else if (R.active == echo::EventType::Echo) TickEcho(now);
        else if (R.active == echo::EventType::Signal) TickSignal(now);
        return;
    }

    if (!C.enabled) return;
    if (R.multiplayerDetected && !C.allowMultiplayer) return;
    if (R.nextAutoAt == 0) ScheduleNext(now);
    if (!echo::timeReached(now, R.nextAutoAt)) return;

    echo::EventType type = PickAutomaticEvent(now);
    if (!StartEvent(type, false)) {
        // One fallback is allowed. A failed heavy event can degrade into SIGNAL
        // rather than hammering model streaming or retrying every logic tick.
        if (type != echo::EventType::Signal && StartEvent(echo::EventType::Signal, false)) return;
        R.nextAutoAt = echo::scheduleAfterMs(now, 15000u);
    }
}

static void OnEnabledChanged(int, int value, void*) {
    C.enabled = value != 0;
    SaveBool("Enabled", C.enabled);
    if (!C.enabled && R.active != echo::EventType::None) R.despawnRequested = true;
}
static void OnIntensityChanged(int, int value, void*) {
    C.intensity = echo::clampIntensity(value);
    SaveInt("Intensity", C.intensity);
    ScheduleNext(sautils->GetCurrentMs());
}
static void OnEyesChanged(int, int value, void*) { C.redEyes = value != 0; SaveBool("RedEyes", C.redEyes); }
static void OnCloneChanged(int, int value, void*) { C.clonePlayerForEcho = value != 0; SaveBool("ClonePlayerForEcho", C.clonePlayerForEcho); }
static void OnMinFPSChanged(int, int value, void*) { C.minFPS = clampi(value, 0, 120); SaveInt("MinFPS", C.minFPS); }
static void OnForceRandom(uintptr_t) { R.force = ForceRequest::Random; }
static void OnForceWatcher(uintptr_t) { R.force = ForceRequest::Watcher; }
static void OnForceEcho(uintptr_t) { R.force = ForceRequest::Echo; }
static void OnForceSignal(uintptr_t) { R.force = ForceRequest::Signal; }
static void OnDespawn(uintptr_t) { R.despawnRequested = true; }

static const char* DrawFPSValue(int value, void*) {
    static char text[24];
    std::snprintf(text, sizeof(text), "%d FPS", value);
    return text;
}

static void InstallSettingsUI() {
    const eTypeOfSettings tab = sautils->AddSettingsTab("ECHO//CITY", "menu_mainsettings");
    sautils->AddClickableItem(tab, "Director", C.enabled ? 1 : 0, 0, 1, kOffOn, OnEnabledChanged);
    sautils->AddClickableItem(tab, "Intensity", C.intensity, 0, 2, kIntensityNames, OnIntensityChanged);
    sautils->AddClickableItem(tab, "Red Eyes", C.redEyes ? 1 : 0, 0, 1, kOffOn, OnEyesChanged);
    sautils->AddClickableItem(tab, "Clone Player Echo", C.clonePlayerForEcho ? 1 : 0, 0, 1, kOffOn, OnCloneChanged);
    sautils->AddSliderItem(tab, "Minimum FPS", C.minFPS, 0, 120, OnMinFPSChanged, DrawFPSValue);
    sautils->AddButton(tab, "FORCE RANDOM", OnForceRandom);
    sautils->AddButton(tab, "FORCE WATCHER", OnForceWatcher);
    sautils->AddButton(tab, "FORCE ECHO", OnForceEcho);
    sautils->AddButton(tab, "FORCE SIGNAL", OnForceSignal);
    sautils->AddButton(tab, "DESPAWN EVENT", OnDespawn);
}

ON_MOD_LOAD() {
    logger->SetTag("ECHO_CITY");
    sautils = reinterpret_cast<ISAUtils*>(GetInterface("SAUtils"));
    gGTASA = aml->GetLibHandle("libGTASA.so");
    if (!sautils || !gGTASA) {
        logger->Error("Missing SAUtils or libGTASA.so; ECHO//CITY disabled");
        return;
    }

    LoadConfig();
    const unsigned int seed = static_cast<unsigned int>(std::time(nullptr)) ^
                              static_cast<unsigned int>(reinterpret_cast<uintptr_t>(gGTASA));
    std::srand(seed);

    IsPlayerOnAMission = reinterpret_cast<bool(*)()>(
        aml->GetSym(gGTASA, "_ZN11CTheScripts18IsPlayerOnAMissionEv")
    );
    R.multiplayerDetected = DetectMultiplayer();

    if (!IsPlayerOnAMission) {
        logger->Print(LogP_Warn, "Mission guard symbol unavailable: automatic encounters fail closed while RequireMissionGuard=1");
    }
    if (R.multiplayerDetected && !C.allowMultiplayer) {
        logger->Print(LogP_Warn, "Multiplayer runtime detected: automatic director disabled (AllowMultiplayer=0)");
    }

    InstallSettingsUI();
    sautils->AddPlayerUpdateListener(OnPlayerUpdate, true);
    ScheduleNext(sautils->GetCurrentMs());

    logger->Info("NOXXA ECHO//CITY v1.0.0 loaded | intensity=%d | LOS=%d | cloneEcho=%d | missionGuard=%s",
                 C.intensity, C.useLineOfSight ? 1 : 0, C.clonePlayerForEcho ? 1 : 0,
                 IsPlayerOnAMission ? "native" : "unavailable");
}

ON_MOD_UNLOAD() {
    if (sautils && R.active != echo::EventType::None) CleanupActive("mod unload");
    logger->Info("Session: WATCHER=%u ECHO=%u SIGNAL=%u rejectedSpawns=%u",
                 R.sessionWatcher, R.sessionEcho, R.sessionSignal, R.spawnRejects);
}
