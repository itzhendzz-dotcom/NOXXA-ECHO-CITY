# Install — NOXXA ECHO//CITY v1.0.0

## Requirements

- GTA: San Andreas Android package `com.rockstargames.gtasa`.
- Android Mod Loader (AML) **1.4+**.
- SAUtils **1.4+** (`net.rusjj.gtasa.utils`).
- One binary matching the ABI actually used by your GTA/AML build.

The project deliberately builds **both** `armeabi-v7a` and `arm64-v8a`. Do not install both copies under the same AML mod directory unless your loader layout explicitly separates ABIs.

## GitHub build — recommended

1. Put the whole source tree in a GitHub repository.
2. Open **Actions → Build ECHO CITY → Run workflow**.
3. Wait for all three jobs to pass: `Host safety gates`, both Android ABI builds, then `Assemble install package`.
4. Download the final artifact. Inside it is a ZIP named similar to `NOXXA_ECHO_CITY_v1.0.0_READY.zip`.
5. Extract it. Pick the `.so` for the ABI used by your GTA/AML install.
6. Copy `libECHO_CITY.so` to the same AML mod location where your other native AML mods are loaded.
7. Make sure SAUtils is installed and active before launching GTA SA.

## First boot / smoke test

Start the game, load a normal outdoor save, then open:

`Settings → ECHO//CITY`

For a controlled test:

1. Set **Director = ON**.
2. Stay on foot, wanted level 0, outdoors.
3. Press **FORCE SIGNAL** first. It requires no ped model and is the cheapest path.
4. Turn until the red eyes become visible, stare briefly, then look away. They should relocate closer.
5. Press **DESPAWN EVENT**.
6. Test **FORCE WATCHER**. It must never advance while actually visible.
7. Walk around on foot for ~15 seconds so the breadcrumb ring fills, then test **FORCE ECHO**.

Manual force mode bypasses night/FPS/mission *admission* so testing is practical, but it still refuses dangerous player states such as vehicle/wanted/interior. If a mission-symbol lookup is unavailable, automatic encounters fail closed while strict mission guard is enabled.

## Config

AML creates the mod configuration for GUID `dev.noxxa.gtasa.echocity`. User-facing options are also available in the ECHO//CITY tab. Advanced keys are intentionally config-only so the menu stays small.

Recommended baseline:

```ini
[Director]
Enabled=1
NightOnly=1
RedEyes=1
ClonePlayerForEcho=1
UseLineOfSight=1
RequireMissionGuard=1
AllowMultiplayer=0
Intensity=1
StartHour=21
EndHour=5
MinFPS=42
LogicTickMs=80
VisibilityTickMs=50
HistoryTickMs=350
```

If your build is extremely mod-heavy, raise `MinFPS` instead of reducing the core safety checks. A higher threshold makes the director skip heavy encounters sooner.

## Multiplayer

Default is **off / refused**. ECHO//CITY detects common SA-MP/RE:SAMP style runtime libraries and refuses automatic encounters unless `AllowMultiplayer=1` is explicitly set. This is intentional: locally-created script peds or object state can conflict with networked entity ownership.

## Uninstall

Remove `libECHO_CITY.so` from the AML mods folder. The configuration can be kept; it is inert without the library.
