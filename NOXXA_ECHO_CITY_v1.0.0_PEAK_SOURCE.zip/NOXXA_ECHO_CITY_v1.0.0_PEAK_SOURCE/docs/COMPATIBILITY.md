# Compatibility & failure modes

## Expected good neighbors

ECHO//CITY does not intentionally patch/render-replace the systems typically owned by:

- timecycle / colorcycle visual mods,
- rain / wet-road mods,
- godray or post-process mods,
- draw-distance mods,
- FLA limit configuration,
- JPatch configuration,
- 2DFX light packs.

Its shared surface is mainly vanilla script opcodes, one SAUtils player-update callback, tiny coronas, and at most one local ped.

## Potential conflicts

### Other mods that own/delete arbitrary script peds

An aggressive cleanup mod could delete the Watcher/ECHO. ECHO//CITY checks `DOES_CHAR_EXIST` and should clean its local state rather than continue using a dead handle.

### Mods that fake/replace camera state

Camera-relative spawn quality can degrade if `GET_ACTIVE_CAMERA_COORDINATES/POINT_AT` returns unusual values. The director falls back to player heading if camera vector is invalid.

### Ped-node/path remaps

Large map replacements can make closest pedestrian nodes surprising. Node snap distance and Z tolerance are configurable, and invalid candidates are rejected rather than forced.

### Multiplayer clients

Disabled by default. Network clients may own entity pools, stream state, or synchronization rules that local script-created peds violate. Explicit override exists only for experimentation.

## Deliberate unsupported cases in v1

- non-zero GTA interior worlds,
- synchronized multiplayer gameplay,
- cutscene/mission integration,
- save-game persistence of an active encounter,
- attacking/combat Watcher behavior.

## Failure philosophy

A horror event failing to appear is acceptable. A horror event corrupting a mission, spawning inside a room, hammering model streaming, or dropping a modded phone into an FC is not. Most ambiguous states therefore resolve to **refuse / cleanup / retry later**.
