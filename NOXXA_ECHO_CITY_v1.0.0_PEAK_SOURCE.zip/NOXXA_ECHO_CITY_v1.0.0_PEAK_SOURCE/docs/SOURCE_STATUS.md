# Source validation status

## Passed in the generation workspace

- deterministic core unit tests;
- 5,000-iteration deterministic geometry property sweep;
- 32-bit timer-wrap tests for director deadlines and breadcrumb queries;
- AddressSanitizer + UndefinedBehaviorSanitizer run;
- full `main.cpp` strict GCC syntax/API-shape gate;
- independent full `main.cpp` strict Clang syntax/API-shape gate;
- shell syntax validation;
- workflow YAML validation;
- global mutation denylist;
- Android.mk recipe/dependency-pin audit;
- stale prototype scan;
- release packaging dry-run with manifest and ZIP integrity validation.

## Not claimed

This workspace did **not** have a usable Android NDK/network path for a real native
compile, and it cannot emulate GTA SA Android entity streaming. Therefore no bundled
`.so` in this source package is claimed as device-tested. The GitHub Actions workflow
performs the actual pinned NDK r27d build for both ABIs and then packages those real
binaries. Final confidence still requires the on-device checklist in `TEST_PLAN.md`.
