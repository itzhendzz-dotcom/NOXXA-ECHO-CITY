# Opcode audit

ECHO//CITY uses SAUtils only as a script-command bridge. The rule for v1.0 is **read state, create at most one local ped, move only that owned ped, draw at most two coronas, and clean up deterministically**.

## Read / query operations

- `01F5 GET_PLAYER_CHAR` — refresh local player script handle.
- `00A0 GET_CHAR_COORDINATES` — player / owned-event ped position.
- `0172 GET_CHAR_HEADING` — fallback view direction when camera query is unavailable.
- `00BF GET_TIME_OF_DAY` — night admission only; never writes time.
- `01C0 STORE_WANTED_LEVEL` — wanted safety gate.
- `00DF IS_CHAR_IN_ANY_CAR` — vehicle safety gate.
- `0117 IS_PLAYER_DEAD`, `0118 IS_CHAR_DEAD`, `056D DOES_CHAR_EXIST` — lifetime validation.
- `02C0 GET_CLOSEST_CHAR_NODE` — pedestrian-node snapping.
- `02CA/02CB` family not relied upon for movement decisions; event peds use `02CB IS_CHAR_ON_SCREEN` together with point visibility.
- `00C2 IS_POINT_ON_SCREEN` — camera-visible destination rejection.
- `068D GET_ACTIVE_CAMERA_COORDINATES`, `068E GET_ACTIVE_CAMERA_POINT_AT` — view-relative spawning.
- `06BD IS_LINE_OF_SIGHT_CLEAR` — optional occlusion/world-block test.
- `077E GET_AREA_VISIBLE` — refuses non-zero GTA interior world IDs.
- `0665 GET_CHAR_MODEL` — ECHO model cloning guard.
- `0339 IS_AREA_OCCUPIED` — spawn collision/crowd rejection and dynamic move obstruction checks.
- `0248 HAS_MODEL_LOADED` — streaming state.

## Owned-entity operations

- `0247 REQUEST_MODEL`, `038B LOAD_ALL_MODELS_NOW`, `0249 MARK_MODEL_AS_NO_LONGER_NEEDED`.
- `009A CREATE_CHAR`, `009B DELETE_CHAR`.
- `00A1 SET_CHAR_COORDINATES`, `0173 SET_CHAR_HEADING`.
- `0350 SET_CHAR_STAY_IN_SAME_PLACE`.
- `0223 SET_CHAR_HEALTH`, `02AB SET_CHAR_PROOFS`, `0446 SET_CHAR_SUFFERS_CRITICAL_HITS`.
- `024F DRAW_CORONA` — two tiny eye coronas maximum.

## Explicit denylist

CI rejects direct `CALLSCM()` use of:

- `FORCE_WEATHER`
- `FORCE_WEATHER_NOW`
- `SET_TIME_SCALE`
- `SET_CAR_DENSITY_MULTIPLIER`
- `DISPLAY_HUD`
- `DISPLAY_RADAR`
- `SET_TIME_OF_DAY`

Those are outside this mod's ownership boundary. ECHO//CITY should coexist with graphics/performance mods rather than silently tuning them.

## Symbol lookup

`CTheScripts::IsPlayerOnAMission()` is resolved by symbol name. No guessed GTASA 2.00/2.10 address is used. If lookup fails and strict mission guard is enabled, automatic events are refused; force-test mode remains available for diagnostics.
