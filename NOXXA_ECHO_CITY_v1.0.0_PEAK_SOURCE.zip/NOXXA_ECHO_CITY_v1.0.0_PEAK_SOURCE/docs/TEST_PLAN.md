# On-device test plan

The host suite proves deterministic math/API shape. It **cannot** prove GTA-specific streaming, node layout, RenderWare visibility, or compatibility with a particular mod stack. Use this checklist before treating a build as daily-driver stable.

## A. Boot sanity

- [ ] Game reaches menu with ECHO//CITY installed.
- [ ] Existing save loads outdoors.
- [ ] `Settings → ECHO//CITY` opens without a blank/crashed settings screen.
- [ ] Toggle Director off/on and restart: value persists.
- [ ] Log contains `NOXXA ECHO//CITY v1.0 loaded` and no missing-dependency error.

## B. SIGNAL — cheapest first

Conditions: outdoor, on foot, wanted 0.

- [ ] `FORCE SIGNAL` produces at most two eye coronas.
- [ ] Eyes do not relocate while being continuously watched.
- [ ] After a short stare + look-away, next stage appears closer.
- [ ] Four-stage sequence eventually cleans itself.
- [ ] `DESPAWN EVENT` removes it immediately.
- [ ] Repeat 20 times around LS streets, hills, beach, underpasses. No eyes inside obviously invalid geometry.

## C. WATCHER visibility invariant

- [ ] `FORCE WATCHER` creates exactly one harmless ped.
- [ ] Keep camera centered on it for 10 seconds: position must remain stable.
- [ ] Look away for several seconds: it may move closer.
- [ ] Rapidly flick camera away/back: no visible teleport should be observed.
- [ ] Put a wall/building between camera and Watcher: occluded movement is allowed.
- [ ] Near finale distance, it should not get stuck indefinitely because of its own collision volume.
- [ ] Catch finale, hold view: it disappears after the intended beat; it never attacks.

## D. ECHO history integrity

- [ ] Walk/run normally for at least 15 seconds before forcing ECHO.
- [ ] ECHO appears near an older path section, not exactly on top of player.
- [ ] While unseen it replays old movement nodes.
- [ ] Observe for >1.2 s: it should stop route replay and face the player.
- [ ] Look away after awareness: it vanishes.
- [ ] Teleport/change far map area, then immediately force ECHO: stale path should be refused rather than pulling an entity from old region.
- [ ] When player model cannot be safely cloned, fallback model is used.

## E. Safety-state transitions

Start an active WATCHER or ECHO, then individually test:

- [ ] Enter vehicle → event cleans up.
- [ ] Gain wanted level → cleanup.
- [ ] Enter non-zero interior world → cleanup.
- [ ] Start story mission → cleanup / auto director blocked.
- [ ] Die/reload → no orphan event survives.
- [ ] Disable Director from menu during event → cleanup request serviced.

## F. Performance regression

Use a reproducible outdoor route and record device/game telemetry before/after mod.

- [ ] Director idle: no meaningful sustained FPS delta versus mod absent.
- [ ] SIGNAL active: effectively neutral.
- [ ] WATCHER visible/unseen cycling: no repeated spikes from model streaming after initial spawn.
- [ ] ECHO active: no runaway CPU cost while replaying 48-sample path.
- [ ] Set `MinFPS` intentionally high, create load, verify ped event watchdog removes itself rather than changing graphics settings.
- [ ] 30-minute free-roam soak: no gradual entity/pool growth and no orphan red coronas.

## G. Mod-stack compatibility

Repeat a smaller smoke set with your normal AML/FLA/JPatch/visual stack enabled.

- [ ] Visual/weather mod behavior unchanged.
- [ ] Existing traffic/ped population settings unchanged.
- [ ] Frame limiter / refresh behavior unchanged.
- [ ] Rain/godrays/fog unchanged.
- [ ] No extra crashes in AML crash log attributable to ECHO_CITY.

## H. ABI matrix

- [ ] armv7 GTA/AML build loads `armeabi-v7a/libECHO_CITY.so`.
- [ ] arm64 GTA/AML build loads `arm64-v8a/libECHO_CITY.so`.
- [ ] Never mix an armv7 `.so` into an arm64 loader or vice versa.

## Reporting a failure

Keep the exact `.so` hash, ABI, AML/SAUtils versions, GTA build/version, last ECHO_CITY log lines, and crash log if any. Also note which force button/event was active and whether the player was entering a vehicle/interior/mission at the time.
