# Architecture — ECHO//CITY v1.0

## 1. Design goal

The mod is a **micro-horror director**, not a mission pack and not a graphics injector. It creates short events that exploit what the camera/player can and cannot see while staying cheap enough for a mod-heavy Android setup.

The hard runtime budget is deliberately tiny:

- **0 or 1 owned ped**
- **0 or 2 coronas**
- no custom textures
- no custom animation archive
- no per-frame heap allocation in event logic
- no shader or framebuffer pass
- no world-density or timecycle mutation

## 2. Update layers

### Render-adjacent layer

Called from SAUtils player-update listener. The eye coronas are drawn here. Visibility sampling is separately throttled (`VisibilityTickMs`) so a 120 Hz display does not mean 120 LOS ray checks per second.

### Logic layer

Runs at `LogicTickMs` (default 80 ms). It refreshes game safety state, records breadcrumbs, services force/despawn requests, executes the active state machine, and starts automatic encounters only when their cooldown expires.

### History layer

Records one breadcrumb every `HistoryTickMs` (default 350 ms) into a fixed 72-entry ring. At default cadence that is about 25 seconds of movement without allocation or file I/O.

## 3. Camera / hidden-position model

A camera vector is built from active camera position → active camera point-at. Spawn probes are generated behind that vector, with randomized angle and lateral offset. Every accepted probe is snapped to a pedestrian node, constrained by horizontal snap radius and Z tolerance, then rejected when:

1. its local area is occupied,
2. it is on-screen and actually visible,
3. its resulting player-distance is implausible for the requested stage.

This prevents the classic CLEO horror-mod failure of spawning a ped directly in front of the camera or inside geometry.

## 4. WATCHER state machine

`SPAWN → OBSERVED/UNSEEN LOOP → FINALE → CLEANUP`

- Spawn 28–40-ish meters behind camera, depending on configured distance/randomization.
- While truly visible, it cannot relocate.
- A long enough stare “charges” the next unseen movement.
- Once unseen for the grace period, it approaches via node-snapped candidate steps.
- Candidate steps are rejected when their destination is visible, path LOS is blocked by world/object geometry, Z change is implausible, or dynamic non-character obstacles occupy the target.
- Step interval and distance can intensify with repeat sightings and the selected global intensity.
- Near the stop radius, it enters a finale state. If the player turns back and catches it there, it holds for a short beat and disappears instead of attacking.

The crucial invariant is: **no accepted supernatural Watcher relocation may happen to a destination that the visibility model currently considers seen.**

## 5. ECHO state machine

`HISTORY WAIT → SPAWN AT OLD TRACK → UNSEEN REPLAY → AWARE HOLD → VANISH`

ECHO samples a point roughly 8.5–14.5 seconds in the player's past. The seed is rejected when too close (<10 m), stale/far (>65 m), or discontinuous. It then copies up to 48 subsequent breadcrumbs into local fixed storage.

While unseen, the owned ped advances through those historical positions. A destination must still pass node plausibility, visibility, and path checks. If the player catches ECHO for long enough, ECHO stops replaying and becomes “aware”: it faces the player. The next time the player genuinely looks away, it disappears.

If enabled, ECHO can borrow the already-loaded normal pedestrian model currently used by the player; otherwise it requests its fallback model. Borrowed models are never marked as no-longer-needed by ECHO because it does not own their streaming lifetime.

## 6. SIGNAL state machine

SIGNAL is the low-cost paranormal event: no ped, only an eye pair.

Stages move through approximate distance bands:

- 38–52 m
- 27–36 m
- 16–24 m
- 8–13 m

The player must first see/stare at a stage. After looking away, SIGNAL waits a brief randomized delay then attempts a hidden relocation to the next band. At the final stage, a completed see → look-away cycle removes it.

Because it owns no ped/model, the director can bias toward SIGNAL when FPS is close to the configured admission threshold.

## 7. Director selection

Three profiles tune cooldown, Watcher aggression, and event weights:

| Profile | Approx cooldown | Character |
|---|---:|---|
| Subtle | 180–360 s | rare, ambiguous, SIGNAL-heavy |
| Balanced | 100–220 s | default mix |
| Nightmare | 55–125 s | more ped events, faster Watcher |

The selector suppresses immediate repetition when alternatives are available. ECHO receives zero effective weight until enough valid breadcrumb history exists.

## 8. Performance safety

Admission and runtime safety are separate:

- **Admission:** non-manual ped events require current/EMA FPS at or above `MinFPS`. SIGNAL gets a lower threshold because it has no ped.
- **Runtime watchdog:** ped events are despawned after roughly 1.5 seconds below 68% of `MinFPS`.
- Visibility/LOS work is throttled independently from game frame rate.
- All state containers are static/fixed-size.

The watchdog does not change graphics settings. It only declines or removes ECHO//CITY's own workload.

## 9. Ownership and cleanup

Every event knows whether it owns its ped model stream. `CleanupActive()` is the single cleanup path. It deletes only the currently owned event ped, releases only an owned requested model, resets event state, records last event, and schedules the next cooldown.

Safety-state changes (vehicle, wanted, interior, mission, multiplayer) also converge on this cleanup path.

## 10. Fail-closed boundaries

- Mission symbol missing + strict guard → no automatic event.
- Multiplayer detected + `AllowMultiplayer=0` → no director event.
- Non-zero interior world → no event.
- Unsafe spawn candidate → reject candidate/event, never “best effort” teleport.
- History discontinuity → ECHO refuses to start.
- Severe FPS collapse → active ped event removed.

Those choices intentionally prefer “nothing happens” over a cool effect that risks corrupt gameplay or causing an FC.
