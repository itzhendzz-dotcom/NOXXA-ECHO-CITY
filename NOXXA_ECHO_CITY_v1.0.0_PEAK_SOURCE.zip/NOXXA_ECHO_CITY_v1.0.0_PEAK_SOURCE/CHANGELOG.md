# Changelog

## v1.0.0 — PEAK rebuild

This is a ground-up expansion of the v0.1 Watcher prototype into a procedural micro-horror director.

### Added

- Three encounter families: **WATCHER**, **ECHO**, and **SIGNAL**.
- Camera-relative hidden spawn search using the active camera position/point-at rather than player heading alone.
- Occlusion-aware visibility: screen-space check + optional world line-of-sight.
- 72-sample movement breadcrumb ring for delayed ECHO route replay.
- Optional player-model cloning for ECHO when the model is a safe normal-ped slot; fallback model otherwise.
- Anti-repeat weighted event selection and three intensity profiles.
- Low-FPS event degradation: tight budgets bias toward SIGNAL instead of spawning a ped.
- Sustained severe-FPS watchdog for active ped encounters.
- Hard interior, wanted, vehicle, mission, multiplayer, and entity-budget safety gates.
- Dedicated force buttons for each encounter and random director test.
- Session counters and rejected-spawn logging.
- Reproducible upstream dependency pins.
- Dual-ABI GitHub Actions matrix build with ELF inspection, hashes, package manifest, and ZIP integrity test.
- Full-main host compile gate against API-shaped AML/SAUtils stubs.
- Pure core tests for geometry, breadcrumb wrap/age lookup, FPS EMA, night windows, director weights, and timer saturation.
- Opcode audit, compatibility matrix, failure-mode document, and on-device regression plan.

### Fixed / hardened

- Replaced invalid prototype `Logger::Warning()` usage with AML's actual `Print(LogP_Warn, ...)` API.
- Kept all SAUtils opcode output storage out of transient stack locals where practical to avoid the ARM64 stack-output failure pattern documented by upstream SAUtils.
- Stopped Watcher movement destination checks from counting the Watcher's own nearby character volume as an obstruction.
- ECHO now refuses stale breadcrumbs more than 65 m from the player.
- Teleport candidates must pass pedestrian-node snap distance and vertical-tolerance validation.
- Visible destination points are rejected before any supernatural relocation.
- Watcher step path is rejected when blocked by world/object line-of-sight.
- Automatic mission behavior is fail-closed when the mission symbol cannot be resolved.

### Intentionally not implemented

- No weather/timecycle mutation.
- No shader, post-process, SSAO, bloom, fog, rain, lightning, or godray modifications.
- No frame-limit, resolution, draw-distance, traffic-density, FLA, or JPatch mutation.
- No networked/multiplayer entity behavior by default.
- No combat AI or damage-to-player mechanic. The horror comes from state/visibility rules, not unfair attacks.
