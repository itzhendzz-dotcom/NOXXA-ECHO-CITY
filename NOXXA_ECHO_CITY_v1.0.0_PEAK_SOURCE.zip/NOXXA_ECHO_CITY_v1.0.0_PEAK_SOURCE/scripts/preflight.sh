#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
CXX="${CXX:-g++}"

echo "[1/11] Pure core tests"
"$CXX" -std=c++17 -O2 -Wall -Wextra -Werror tests/test_core.cpp -o /tmp/echo_city_core_tests
/tmp/echo_city_core_tests

echo "[2/11] ASan + UBSan core tests"
"$CXX" -std=c++17 -O1 -g -Wall -Wextra -Werror \
  -fsanitize=address,undefined -fno-omit-frame-pointer \
  tests/test_core.cpp -o /tmp/echo_city_sanitized_tests
ASAN_OPTIONS=detect_leaks=1 /tmp/echo_city_sanitized_tests

echo "[3/11] Whole-main GCC API-shape syntax gate"
"$CXX" -std=gnu++17 -O0 -Wall -Wextra -Werror -Itests/stubs -I. -fsyntax-only main.cpp

echo "[4/11] Whole-main Clang API-shape syntax gate"
if command -v clang++ >/dev/null 2>&1; then
  clang++ -std=gnu++17 -O0 -Wall -Wextra -Werror -Itests/stubs -I. -fsyntax-only main.cpp
else
  echo "clang++ unavailable; GCC gate remains authoritative"
fi

echo "[5/11] Shell syntax"
bash -n scripts/fetch_deps.sh scripts/build.sh scripts/preflight.sh scripts/package.sh

echo "[6/11] Workflow YAML parse"
python3 - <<'PY'
from pathlib import Path
text = Path('.github/workflows/build.yml').read_text()
try:
    import yaml
except ImportError:
    assert 'jobs:' in text and 'upload-artifact' in text and '27.3.13750724' in text
else:
    parsed = yaml.safe_load(text)
    assert isinstance(parsed, dict)
assert 'preflight:' in text and 'android:' in text and 'release:' in text
assert 'armeabi-v7a' in text and 'arm64-v8a' in text
print('workflow: OK')
PY

echo "[7/11] Global-mutation denylist"
if grep -nE 'CALLSCM\((FORCE_WEATHER|FORCE_WEATHER_NOW|SET_TIME_SCALE|SET_CAR_DENSITY_MULTIPLIER|DISPLAY_HUD|DISPLAY_RADAR|SET_TIME_OF_DAY)' main.cpp; then
  echo "Forbidden global-state mutation found" >&2
  exit 1
fi

echo "[8/11] Android recipe audit"
grep -q 'mod/logger.cpp' Android.mk
grep -q 'mod/config.cpp' Android.mk
grep -q 'APP_ABI := armeabi-v7a arm64-v8a' Application.mk
grep -q '5588ed242b8e49fc1def572aef89c6c9e745aa34' scripts/fetch_deps.sh
grep -q 'ace8752de2d0fa502b027bd0a9c6ca2d3bcd04e8' scripts/fetch_deps.sh
grep -q '27.3.13750724' .github/workflows/build.yml

echo "[9/11] Stale/prototype marker scan"
if grep -RInE 'v0\.1|test_logic\.cpp|Logger::Warning|logger->Warning' \
  main.cpp Android.mk Application.mk README.md INSTALL.md docs \
  scripts/build.sh scripts/fetch_deps.sh scripts/package.sh .github tests/test_core.cpp; then
  echo "Stale/prototype build marker found" >&2
  exit 1
fi

echo "[10/11] Packaging dry-run"
PKG_TMP="$(mktemp -d "${TMPDIR:-/tmp}/echo-city-pkg.XXXXXX")"
trap 'rm -rf "$PKG_TMP"' EXIT
cp -R . "$PKG_TMP/project"
mkdir -p "$PKG_TMP/project/libs/armeabi-v7a" "$PKG_TMP/project/libs/arm64-v8a"
printf 'dry-run-armv7\n' > "$PKG_TMP/project/libs/armeabi-v7a/libECHO_CITY.so"
printf 'dry-run-arm64\n' > "$PKG_TMP/project/libs/arm64-v8a/libECHO_CITY.so"
(
  cd "$PKG_TMP/project"
  ./scripts/package.sh >/dev/null
  VERSION_NOW="$(tr -d '\r\n' < VERSION)"
  ZIP="release/NOXXA_ECHO_CITY_${VERSION_NOW}_READY.zip"
  unzip -t "$ZIP" >/dev/null
  test -s "${ZIP}.sha256"
  python3 - <<'PY'
import json, pathlib
version = pathlib.Path('VERSION').read_text().strip()
manifest_path = pathlib.Path('release') / f'NOXXA_ECHO_CITY_{version}' / 'manifest.json'
manifest = json.loads(manifest_path.read_text())
assert manifest['version'] == version
assert manifest['abis'] == ['armeabi-v7a', 'arm64-v8a']
assert manifest['hard_entity_budget'] == {'peds': 1, 'coronas': 2}
PY
)

echo "[11/11] Release metadata"
test -s VERSION
test -s README.md
test -s INSTALL.md
test -s CHANGELOG.md
test -s docs/ARCHITECTURE.md
test -s docs/TEST_PLAN.md
test -s docs/OPCODE_AUDIT.md
test -s docs/COMPATIBILITY.md

echo "ECHO//CITY preflight: PASS"
