#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ ! -d mod || ! -f isautils.h || ! -f sa_scripting.h ]]; then
  ./scripts/fetch_deps.sh
fi

: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to your Android NDK path}"

rm -rf libs obj
"$ANDROID_NDK_HOME/ndk-build" \
  NDK_PROJECT_PATH="$ROOT" \
  APP_BUILD_SCRIPT="$ROOT/Android.mk" \
  NDK_APPLICATION_MK="$ROOT/Application.mk" \
  -j2

test -s libs/armeabi-v7a/libECHO_CITY.so
test -s libs/arm64-v8a/libECHO_CITY.so

echo "Built:"
ls -lh libs/armeabi-v7a/libECHO_CITY.so libs/arm64-v8a/libECHO_CITY.so
