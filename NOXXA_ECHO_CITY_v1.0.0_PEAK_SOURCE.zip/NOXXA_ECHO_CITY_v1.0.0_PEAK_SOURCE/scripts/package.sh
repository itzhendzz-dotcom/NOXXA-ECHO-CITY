#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
VERSION="$(tr -d '\r\n' < VERSION)"
OUT="release/NOXXA_ECHO_CITY_${VERSION}"

rm -rf release
mkdir -p "$OUT/armeabi-v7a" "$OUT/arm64-v8a" "$OUT/docs"
cp libs/armeabi-v7a/libECHO_CITY.so "$OUT/armeabi-v7a/"
cp libs/arm64-v8a/libECHO_CITY.so "$OUT/arm64-v8a/"
cp README.md INSTALL.md CHANGELOG.md VERSION "$OUT/"
cp docs/ARCHITECTURE.md docs/TEST_PLAN.md docs/OPCODE_AUDIT.md docs/COMPATIBILITY.md docs/SOURCE_STATUS.md "$OUT/docs/"

(
  cd "$OUT"
  sha256sum armeabi-v7a/libECHO_CITY.so arm64-v8a/libECHO_CITY.so > SHA256SUMS.txt
)

ECHO_PACKAGE_OUT="$OUT" ECHO_PACKAGE_VERSION="$VERSION" python3 - <<'PY'
import json, os, pathlib
out = pathlib.Path(os.environ["ECHO_PACKAGE_OUT"])
manifest = {
    "name": "NOXXA ECHO//CITY",
    "version": os.environ["ECHO_PACKAGE_VERSION"],
    "abis": ["armeabi-v7a", "arm64-v8a"],
    "minimum_aml": "1.4",
    "minimum_sautils": "1.4",
    "game": "com.rockstargames.gtasa",
    "hard_entity_budget": {"peds": 1, "coronas": 2},
}
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
PY

mkdir -p release
(
  cd release
  zip -qr "NOXXA_ECHO_CITY_${VERSION}_READY.zip" "NOXXA_ECHO_CITY_${VERSION}"
)
sha256sum "release/NOXXA_ECHO_CITY_${VERSION}_READY.zip" > "release/NOXXA_ECHO_CITY_${VERSION}_READY.zip.sha256"
echo "Packaged release/NOXXA_ECHO_CITY_${VERSION}_READY.zip"
