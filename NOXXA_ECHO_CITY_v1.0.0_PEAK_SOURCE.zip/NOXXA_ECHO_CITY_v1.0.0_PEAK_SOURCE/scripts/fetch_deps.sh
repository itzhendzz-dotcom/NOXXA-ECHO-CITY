#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

# Reproducible upstream snapshots. Update deliberately, never silently by
# following a moving branch during a release build.
AML_COMMIT="5588ed242b8e49fc1def572aef89c6c9e745aa34"
SAUTILS_COMMIT="ace8752de2d0fa502b027bd0a9c6ca2d3bcd04e8"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/echo-city-deps.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/aml"

# Stage everything first. A DNS/network failure must never delete a previously
# usable local dependency snapshot.
curl --fail --location --retry 3 --retry-delay 2 \
  "https://github.com/AndroidModLoader/AndroidModLoader/archive/${AML_COMMIT}.tar.gz" \
  -o "$TMP/aml.tar.gz"
tar -xzf "$TMP/aml.tar.gz" -C "$TMP/aml" --strip-components=1

test -s "$TMP/aml/mod/amlmod.h"
test -s "$TMP/aml/mod/logger.cpp"
test -s "$TMP/aml/mod/config.cpp"

curl --fail --location --retry 3 --retry-delay 2 \
  "https://raw.githubusercontent.com/AndroidModLoader/SAUtils/${SAUTILS_COMMIT}/isautils.h" \
  -o "$TMP/isautils.h"
curl --fail --location --retry 3 --retry-delay 2 \
  "https://raw.githubusercontent.com/AndroidModLoader/SAUtils/${SAUTILS_COMMIT}/sa_scripting.h" \
  -o "$TMP/sa_scripting.h"
test -s "$TMP/isautils.h"
test -s "$TMP/sa_scripting.h"

grep -q 'class ISAUtils' "$TMP/isautils.h"
grep -q 'ScriptCommand' "$TMP/isautils.h"
grep -q 'MYMOD' "$TMP/aml/mod/amlmod.h"

# Commit staged snapshot atomically-ish only after every required file passed.
rm -rf mod.new
cp -R "$TMP/aml/mod" mod.new
cp "$TMP/isautils.h" isautils.h.new
cp "$TMP/sa_scripting.h" sa_scripting.h.new

rm -rf mod
mv mod.new mod
mv isautils.h.new isautils.h
mv sa_scripting.h.new sa_scripting.h
printf '%s\n' "$AML_COMMIT" > .aml-commit
printf '%s\n' "$SAUTILS_COMMIT" > .sautils-commit

echo "Dependencies ready"
echo "  AML:     $AML_COMMIT"
echo "  SAUtils: $SAUTILS_COMMIT"
